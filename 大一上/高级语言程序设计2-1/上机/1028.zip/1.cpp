#include<iostream>
using namespace std;
int main()
{
	int n;
	cin >> n;
	for (int i = 1; i <= n / 2 + 1; i++)
	{
		for (int j = 0; j < i; j++)
			cout << "*";
		for (int j = 0; j < n + 1 - 2 * i; j++)
			cout << " ";
		for (int j = 0; j < i; j++)
			cout << "*";
		cout << endl;
	}
	for (int i = n / 2; i >= 1; i--)
	{
		for (int j = 0; j < i; j++)
			cout << "*";
		for (int j = 0; j < n + 1 - 2 * i; j++)
			cout << " ";
		for (int j = 0; j < i; j++)
			cout << "*";
		cout << endl;
	}
	return 0;
}