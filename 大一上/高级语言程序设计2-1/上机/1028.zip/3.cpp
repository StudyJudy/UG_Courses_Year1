#include<iostream>
using namespace std;
int main()
{
	double mark[7], sum=0;
	for (int i = 0; i < 7; i++)
		cin >> mark[i];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 6; j > i; j--)
		{
			if (mark[j] < mark[j - 1])
			{
				double temp = mark[j];
				mark[j] = mark[j - 1];
				mark[j - 1] = temp;
			}
		}
	}
	for (int i = 1; i <= 5; i++)
		sum += mark[i];
	cout << sum / 5 << endl;
	return 0;
}