#include<iostream>
#include<cstring>
using namespace std;
int main()
{
	char str1[21],str2[21];
	cin >> str1 >> str2;
	cout << str1;
	for (int i = strlen(str2) - 1;i >= 0;i--)
		cout << str2[i];
	cout << endl;
	return 0;
}