#include<iostream>
#include<cstring>
using namespace std;
int main()
{
	char s[81];
	int time[26] = { 0 };
	cin.getline(s,81);
	for (int i = 0; i < strlen(s); i++)
	{
		if (s[i] >= 'A' && s[i] <= 'Z')
			time[s[i] - 65]++;
		if (s[i] >= 'a' && s[i] <= 'z')
			time[s[i] - 97]++;
	}
	for (int i = 0;i < 26;i++)
	{
		if (time[i] != 0)
		{
			cout << char(i + 97) << ":";
			for (int j = 0;j < time[i];j++)
				cout << "*";
			cout << endl;
		}
	}
	return 0;
}