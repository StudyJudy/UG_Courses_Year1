#include<iostream>
using namespace std;
int main()
{
	int t[20][20];
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < i + 1; j++)
		{
			if ( j == 0 || j == i)
				t[i][j] = 1;
			else
				t[i][j] = t[i - 1][j - 1] + t[i - 1][j];
		}
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < i + 1; j++)
			cout << t[i][j] << " ";
		cout << endl;
	}
	return 0;
}