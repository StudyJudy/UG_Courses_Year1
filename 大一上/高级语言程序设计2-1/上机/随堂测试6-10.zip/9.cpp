#include <iostream>
using namespace std;
void reverse_substr(char str[], int digit_begin, int digit_end)
{
	while (digit_begin < digit_end)
	{
		char tmp = str[digit_begin];
		str[digit_begin] = str[digit_end];
		str[digit_end] = tmp;
		digit_begin++;
		digit_end--;
	}
	return;
}
int main()
{
	char str[51];
	cin >> str;
	int digit_begin = -1, digit_end = -1;
	int i = 0;
	while (str[i] != 0)
	{
		if (str[i] >= '0' && str[i] <= '9')
		{
			if (digit_begin == -1)
				digit_begin = digit_end = i;
			else
				digit_end = i;
		}
		else
		{
			if (digit_begin != -1)
			{
				reverse_substr(str, digit_begin, digit_end);
				digit_begin = digit_end = -1;
			}
		}
		i++;
	}
	reverse_substr(str, digit_begin, digit_end);
	cout << str << endl;
	return 0;
}