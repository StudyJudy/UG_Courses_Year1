#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
struct Candidate
{
	char name[21];
	char sextype;
	int score;
} candidates[100000];
bool cmp_name_asc(Candidate x, Candidate y) { return strcmp(x.name, y.name) < 0; }
bool cmp_score_desc(Candidate x, Candidate y) { return x.score > y.score; }
int main()
{
	int n, m, k, f_num = 0, m_num = 0, x = 0, enroll_num = 0;
	cin >> n >> m >> k;
	for (int i = 0; i < n; i++)
	{
		Candidate tmp;
		cin >> tmp.name >> tmp.sextype >> tmp.score;
		if (tmp.sextype == 'F')
			candidates[f_num++] = tmp;
		else
			candidates[n - 1 - m_num++] = tmp;
	}
	sort(candidates, candidates + f_num, cmp_score_desc);
	sort(candidates + f_num, candidates + n, cmp_score_desc);
	if (f_num <= k)
		x = f_num;
	else
	{
		x = k;
		for (int i = k; i < f_num && candidates[i].score >= candidates[k - 1].score; i++)
			x++;
	}
	enroll_num = x;
	if (x < m)
	{
		for (int i = 0; candidates[f_num + i].score >= candidates[f_num + m - x - 1].score && f_num + i < n; i++)
		{
			candidates[x + i] = candidates[f_num + i];
			enroll_num++;
		}
	}
	sort(candidates, candidates + enroll_num, cmp_name_asc);
	for (int i = 0; i < enroll_num; i++)
		cout << candidates[i].name << endl;
	return 0;
}