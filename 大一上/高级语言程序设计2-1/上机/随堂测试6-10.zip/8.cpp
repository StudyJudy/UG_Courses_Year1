#include <iostream>
using namespace std;
int main()
{
	char str1[51], str2[51];
	cin >> str1;
	int str1_i = 0, str2_i = 0;
	while (str1[str1_i] != 0)
	{
		if (str1[str1_i] >= 'A' && str1[str1_i] <= 'Z')
			str2[str2_i++] = str1[str1_i] + 'a' - 'A';
		else if (str1[str1_i] >= 'a' && str1[str1_i] <= 'z')
			str2[str2_i++] = str1[str1_i] + 'A' - 'a';
		str1_i++;
	}
	str2[str2_i] = 0;
	cout << str2 << endl;
	return 0;
}