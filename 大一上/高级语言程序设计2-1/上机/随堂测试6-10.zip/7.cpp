#include <iostream>
using namespace std;
int main()
{
	char str[51];
	cin >> str;
	int count[26] = { 0 };
	int j = 0;
	while (str[j] != 0)
		count[str[j++] - 'a']++;
	j = 51;
	for (int i = 0; i < 26; i++)
		if (count[i] != 0)
			j = j < count[i] ? j : count[i];
	for (int i = 0; i < 26; i++)
		if (count[i] == j)
			cout << char(i + 'a') << endl;
	return 0;
}