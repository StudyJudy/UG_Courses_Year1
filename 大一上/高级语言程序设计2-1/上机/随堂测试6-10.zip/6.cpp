#include <iostream>
using namespace std;
struct Student
{
	int no;
	char name[11];
};
bool operator<(Student s1, Student s2) { return s1.no < s2.no; }
int main()
{
	int n;
	Student stu[20];
	cin >> n;
	for (int i = 0; i < n; i++)
		cin >> stu[i].name >> stu[i].no;
	for (int i = 0; i < n; i++)
		for (int j = n - 1; j > i; j--)
			if (stu[j - 1] < stu[j])
			{
				Student tmp = stu[j];
				stu[j] = stu[j - 1];
				stu[j - 1] = tmp;
			}
	for (int i = 0; i < n; i++)
		cout << stu[i].name << endl;
	return 0;
}