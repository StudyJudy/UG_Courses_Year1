#include <iostream>
using namespace std;

int end_zeros(int *A, int nSize)
{
	int end = nSize - 1;
	for (int i = 0; i < end; i++)
	{
		if (A[i] == 0)
		{
			//找到尾部不为0的元素位置
			while (A[end] == 0)
				end--;
			//将0元素放置于数组尾部
			int t = A[end];
			A[end] = A[i];
			A[i] = t;
		}
	}
	return end; //返回值为原数据中第一个元素为0的下标
}

int main()
{
	int *a = new int[2000];
	char c;
	int num = 0;
	while ((c = getchar()) != '\n') //流中一个字符一个字符判断，直到换行，输入结束
	{
		if (c != ' ')
		{
			ungetc(c, stdin);	 //如果字符c不是空格，就要将c字符还回到流中，不然造成数据读取错误
			cin >> *(a + num++); //流输入会将第一个数据全读入，直到遇到空格
		}
	}
	int index = end_zeros(a, num);
	for (int i = 0; i < index; i++)
		cout << *(a + i) << " ";
	cout << index;

	delete[] a;
	return 0;
}