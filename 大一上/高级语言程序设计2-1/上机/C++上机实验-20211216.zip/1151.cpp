#include <iostream>
using namespace std;

// 最大值
double Max(double *p, int n)
{
	double max = 0;
	for (int i = 0; i < n; i++)
	{
		if (*(p + i) > max)
			max = *(p + i);
	}
	return max;
}

// 平均值
double Ave(double *p, int n)
{
	double add = 0;
	for (int i = 0; i < n; i++)
	{
		add += *(p + i);
	}
	return add / n;
}

int main()
{
	int n;
	cin >> n;
	double *p;
	p = new double[n];
	for (int i = 0; i < n; i++)
	{
		cin >> *(p + i);
	}

	cout << Ave(p, n) << endl;
	cout << Max(p, n);

	delete[] p;
	return 0;
}