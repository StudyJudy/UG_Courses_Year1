#include <iostream>
using namespace std;

void swap(int *a, int *b)
{
    int t = *a; // 这里的*是间接访问运算符（取内容），和上面用来声明指针变量的*一定要区分
    *a = *b;
    *b = t;
}

int main()
{
    // 输入
    int *nums = new int[10];
    for (int i = 0; i < 10; i++)
    {
        cin >> nums[i];
    }

    // 交换
    for (int i = 0; i < 5; i++)
    {
        swap(nums + i, nums + 9 - i);
    }

    // 输出
    for (int i = 0; i < 9; i++)
    {
        cout << nums[i] << " ";
    }
    cout << nums[9] << endl;

    // 释放内存
    delete nums;
    return 0;
}