﻿#include <iostream>
#include <ctime>
using namespace std;

void swap(int &a, int &b)
{
    int t = a;
    a = b;
    b = t;
}

void print(int* arr, int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        cout << arr[i] << " ";
    }
    cout << arr[n - 1] << endl;
}

void bubble_sort(int* arr, int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - 1 - i; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                swap(arr[j], arr[j + 1]);
            }
            //cout << "debug: " << i << ", " << j << ":   ";
            //print(arr, n);
        }
        //cout << "debug: " << i << ": ";
        //print(arr, n);
    }
}

int main()
{
    //srand((unsigned int)time(NULL));
    int arr[10] = { 0 };
    for (int i = 0; i < 10; i++)
    {
        arr[i] = rand() % 100;
    }
    print(arr, 10);
    bubble_sort(arr, 10);
    print(arr, 10);

    return 0;
}