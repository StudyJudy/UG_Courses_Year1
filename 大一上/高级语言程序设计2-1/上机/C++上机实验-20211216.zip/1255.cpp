#include <iostream>
using namespace std;

/**
 * 本题条件下只能存在零个或一个鞍点。反证即可。
 * 假设存在两个鞍点，设为 a[i1][j1]，a[i2][j2]（i1 != i2 且 j1 != j2），
 * 根据鞍点性质
 * 应有   a[i1][j1] < a[i2][j1] < a[i2][j2]   --- (1)
 * 同时有 a[i1][j1] > a[i1][j2] > a[i2][j2]   --- (2)
 * (1)(2)矛盾，假设不成立。
 */
int main()
{
    int n, m;
    cin >> n >> m;
    // 注意动态二维数组的初始化
    int **matrix = new int *[n];
    for (int i = 0; i < n; i++)
    {
        matrix[i] = new int[m];
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> matrix[i][j];
        }
    }

    int count = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            // 记录满不满足条件
            bool flag = false;
            for (int k = 0; k < n; k++)
            {
                if (matrix[k][j] < matrix[i][j])
                {
                    // 判断这一列中有没有比当前点小的
                    flag = true;
                    break;
                }
            }
            for (int k = 0; k < m; k++)
            {
                if (matrix[i][k] > matrix[i][j])
                {
                    // 判断这一行中有没有比当前点大的
                    flag = 1;
                    break;
                }
            }
            if (!flag)
            {
                // 满足条件
                count++;
                cout << i + 1 << " " << j + 1 << " " << matrix[i][j] << endl;
            }
        }
    }
    if (count == 0)
    {
        cout << "no" << endl;
    }

    // 释放内存
    for (int i = 0; i < count; i++)
    {
        delete matrix[i];
    }
    delete matrix;

    return 0;
}
