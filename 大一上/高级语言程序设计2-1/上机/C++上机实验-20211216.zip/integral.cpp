#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

double func1(double x) { return x * x; }
double func2(double x) { return sin(x); }
double func3(double x) { return 1 / x; }

double integral(double (*f)(double), double a, double b, int n)
{
    double result = 0;
    double delta = (b - a) / n;
    for (double i = a + delta / 2; i < b; i += delta)
    {
        result += f(i) * delta;
    }
    return result;
}

int main()
{
    double a, b;
    int n;
    cin >> a >> b >> n;
    cout << fixed << setprecision(4) << integral(func1, a, b, n) << endl;
    cout << fixed << setprecision(4) << integral(func2, a, b, n) << endl;
    cout << fixed << setprecision(4) << integral(func3, a, b, n) << endl;

    return 0;
}