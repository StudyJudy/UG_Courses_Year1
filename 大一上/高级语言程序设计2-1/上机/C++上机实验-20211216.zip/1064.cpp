#include <iostream>
#include <cstring>
using namespace std;

// cin:  qwert 2
// cout: rtqwe
int main()
{
    // 输入
    char *str = new char[100];
    cin >> str;
    int n;
    cin >> n;

    // 处理
    int len = strlen(str);
    n %= len;

    // tmp 只是一个临时存放字符的数组的首地址，不能作为一个字符串，不会放'\0'
    char *tmp = new char[n];
    // 把左边的字符先复制到 tmp 指向的数组中
    // str: qwert\0
    // tmp: rt
    char *src = str + len - n, *dst = tmp;
    while (*src != '\0')
    {
        *(dst++) = *(src++);
    }

    // 左边的字符向右移动，为了防止覆盖，需要从右往左依次移动
    // str: qwert\0
    // str: qwqwe\0
    src = str + len - n - 1, dst = str + len - 1;
    for (int i = 0; i < len - n; i++)
    {
        *(dst--) = *(src--);
    }

    // 将 tmp 指向数组中的字符复制到左边
    // str: qwqwe\0 tmp: rt
    // str: rtqwe\0
    src = tmp, dst = str;
    for (int i = 0; i < n; i++)
    {
        *(dst++) = *(src++);
    }

    // 输出
    cout << str << endl;

    // 释放内存
    delete str;
    delete tmp;

    return 0;
}