#include<iostream>
#include<algorithm>
using namespace std;

/*交换两个整数的值*/
void swap(int* p, int* q)
{
    int tmp;
    tmp = *p;
    *p = *q;
    *q = tmp;
    return;
}

/*查找一个有序数组中的平均数*/
double find_avg_number(int* arr, int len)
{
    int sum = 0;
    for (int i = 0; i < len; i++)
    {
        sum += *(arr + i);
    }
    return (double)sum / len;
}

/*查找一个有序数组中的中位数*/
double find_mid_number(int* arr, int len)
{
    if (len % 2 == 0)//当数字个数为偶数时
    {
        return (*(arr + (len - 1) / 2) + *(arr + len / 2)) / 2.0;
    }
    else
    {
        return *(arr + len / 2);
    }
}

/*查找一个有序数组中的众数*/
int find_mode_number(int* arr, int len)
{
    int many = 1, less = 1;
    int value = 0;
    for (int i = 0; i < len; i++)
    {
        for (int j = i; j < len; j++)
        {
            if (*(arr + j) == *(arr + j + 1))
            {
                less++;
            }
            else
            {
                if (many <= less)
                {
                    many = less;
                    value = *(arr + j);
                }
                less = 1;
                break;
            }
        }
    }
    return value;
}

int main()
{
    int n;
    cin >> n;
    int* a = new int[n];
    for (int i = 0; i < n; i++)
    {
        cin >> *(a + i);
    }
    sort(a, a + n);
    double avg = find_avg_number(a, n);
    double mid_num = find_mid_number(a, n);
    int count = find_mode_number(a, n);
    cout << avg << " " << mid_num << " " << count << endl;
    delete[] a;
    return 0;
}

