#include <iostream>
using namespace std;
int main7()
{
	char board[9][9];
	for (int i = 0; i < 9; i++)
	{
		for (int j = 0; j < 9; j++)
		{
			cin >> board[i][j];
		}
	}
	// check row
	for (int i = 0; i < 9; i++)
	{
		int check[9] = { 0 };
		for (int j = 0; j < 9; j++)
		{
			if (board[i][j] == '0')
			{
				continue;
			}
			if (check[board[i][j] - '1'] != 0)
			{
				cout << "false" << endl;
				return 0;
			}
			check[board[i][j] - '1'] = 1;
		}
	}
	// check col
	for (int i = 0; i < 9; i++)
	{
		int check[9] = { 0 };
		for (int j = 0; j < 9; j++)
		{
			if (board[j][i] == '0')
			{
				continue;
			}
			if (check[board[j][i] - '1'] != 0)
			{
				cout << "false" << endl;
				return 0;
			}
			check[board[j][i] - '1'] = 1;
		}
	}
	// check block
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			int check[9] = { 0 };
			for (int ii = i * 3; ii < i * 3 + 3; ii++)
			{
				for (int jj = j * 3; jj < j * 3 + 3; jj++)
				{
					if (board[ii][jj] == '0')
					{
						continue;
					}
					if (check[board[ii][jj] - '1'] != 0)
					{
						cout << "false" << endl;
						return 0;
					}
					check[board[ii][jj] - '1'] = 1;
				}
			}
		}
	}
	cout << "true" << endl;
	return 0;
}
