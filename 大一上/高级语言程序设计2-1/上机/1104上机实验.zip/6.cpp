#include<iostream>
using namespace std;
int main()
{
	int n, sum = 0, i, j;
	cin >> n;
	for (i = 2; i <= n; i++)
	{
		for (j = 2; j * j <= i; j++)
		{
			if (i % j == 0)
			{
				break;
			}
		}
		// ѭ��������ֹ
		if (j * j > i)
		{	
			sum += i;// i������
		}
	}
	cout << sum << endl;
	return 0;
}