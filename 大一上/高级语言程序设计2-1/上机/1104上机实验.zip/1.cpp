#include<iostream>
using namespace std;
int main()
{
	int a[10000], len, n;
	for (int i = 0; i < len; i++)
	{
		cin >> a[i];
	}
	cin >> n;
	for (int i = 0; i < 10; i++)
	{
		if (a[i] == n)
		{
			cout << i + 1 << endl;
			return 0;
		}
	}
	cout << "not found" << endl;
	return 0;
}