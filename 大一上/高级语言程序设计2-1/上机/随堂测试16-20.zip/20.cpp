#include<iostream>
using namespace std;
int main() {
	long long int n;
	cin >> n;
	long long int ans = 1;
	for (int i = 1; i <= n; i++) {
		ans *= i;
	}
	int count = 0;
	while (ans) {
		if (ans % 10 == 0)
			count++;
		ans = ans / 10;
	}
	cout << count;
	return 0;
}