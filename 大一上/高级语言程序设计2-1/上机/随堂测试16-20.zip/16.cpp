#include <iostream>
#include <cstring>
using namespace std;

void reverse(char s[], int start, int end)
{
    while (start < end)
    {
        char c = s[start];
        s[start] = s[end];
        s[end] = c;
        start++;
        end--;
    }
}

void solve()
{
    char s[16];
    char op;
    int n;
    cin >> s >> op >> n;
    int len = strlen(s);
    n %= len;
    switch (op)
    {
    case 'L':
        reverse(s, 0, len - 1);
        reverse(s, 0, len - n - 1);
        reverse(s, len - n, len - 1);
        break;
    case 'R':
        reverse(s, 0, len - 1);
        reverse(s, 0, n - 1);
        reverse(s, n, len - 1);
        break;
    default:
        break;
    }
    for (int i = 0; i < len; i += 2)
    {
        cout << s[i];
    }
    cout << endl;
}

int main()
{
    int t;
    cin >> t;
    while (t-- > 0)
    {
        solve();
    }

    return 0;
}
