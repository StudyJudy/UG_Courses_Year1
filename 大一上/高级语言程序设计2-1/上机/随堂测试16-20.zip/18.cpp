#include<iostream>
#include<cstring>
using namespace std;
int main() {
	char str[100];
	cin.getline(str, 100);
	int len = strlen(str);
	int idx = 0;
	for (int i = 0; i < len; i++) {
		if (str[i] >= '0' && str[i] <= '9' || str[i] >= 'a' && str[i] <= 'z' || str[i] >= 'A' && str[i] <= 'Z')
			str[idx++] = str[i];
	}
	str[idx] = '\0';
	char* first = str;
	char* last = str + idx - 1;
	bool whe = true;
	while (first < last) {
		if (*first != *last)
			whe = false;
		first++;
		last--;
	}
	if (whe)
		cout << "True";
	else
		cout << "False";

	return 0;
}