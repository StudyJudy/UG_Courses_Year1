#include<iostream>
using namespace std;
int main() {
	int matrix[10][10];
	int m, n;
	int x, y;
	int sum;
	double avg;
	cin >> m >> n;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			cin >> matrix[i][j];
		}
	}
	cin >> x >> y;
	if (x < 0 || x >= m || y < 0 || y >= n) {
		cout << "WRONG INPUT!" << endl;
		return 0;
	}
	sum = 0;
	for (int i = 0; i <= x; i++) {
		for (int j = 0; j <= y; j++) {
			sum += matrix[i][j];
		}
	}
	avg = (double)sum / ((x + 1) * (y + 1));
	sum = 0;
	for (int i = 0; i <= x; i++) {
		for (int j = y + 1; j < n; j++) {
			sum += matrix[i][j];
		}
	}
	if ((n - y - 1) != 0) {
		avg = avg >= (double)sum / ((x + 1) * (n - y - 1)) ? avg : (double)sum / ((x + 1) * (n - y - 1));
	}
	sum = 0;
	for (int i = x + 1; i < m; i++) {
		for (int j = 0; j <= y; j++) {
			sum += matrix[i][j];
		}
	}
	if ((m - x - 1) != 0) {
		avg = avg >= (double)sum / ((m - x - 1) * (y + 1)) ? avg : (double)sum / ((m - x - 1) * (y + 1));
	}
	sum = 0;
	for (int i = x + 1; i < m; i++) {
		for (int j = y + 1; j < n; j++) {
			sum += matrix[i][j];
		}
	}
	if ((m - x - 1) * (n - y - 1) != 0) {
		avg = avg >= (double)sum / ((m - x - 1) * (n - y - 1)) ? avg : (double)sum / ((m - x - 1) * (n - y - 1));
	}
	cout << avg << endl;
	return 0;
}