#include<iostream>
using namespace std;
int main() {
	int n, sum = 0;
	cin >> n;
	for (int i = 1; i <= n; i++) {//ע��ѭ���Ǵ�1��ʼ
		sum += i;
	}
	cout << sum;
	return 0;
}