#include<iostream>
using namespace std;
int main() {
	int n;
	cin >> n;
	if (n < 0) {
		cout << "-";
		n = -n;
	}
	int sum = 0;
	while (n != 0) {
		sum = sum * 10 + n % 10;
		n /= 10;//ȥ����λ
	}
	/* ��
	* sum = 0 n = 123
	* sum = 3 n = 12
	* sum = 32 n = 1
	* sum = 321 n = 0
	*/
	cout << sum << endl;
	return 0;
}