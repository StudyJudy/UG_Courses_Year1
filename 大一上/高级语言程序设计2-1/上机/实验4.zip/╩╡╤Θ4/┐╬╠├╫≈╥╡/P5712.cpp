#include<iostream>
using namespace std;

int main() 
{
    int x;
    cin >> x;

    cout << "Today, I ate " << x;
    if (x <= 1)
    {
        cout<<" apple.";
    }
    else
    {
        cout<<" apples.";
    }

    return 0;
}
