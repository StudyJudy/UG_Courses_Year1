#include<iostream>
using namespace std;

int main() 
{
    int x;
    cin >> x;

    bool a = (x % 2 == 0);
    bool b = (x > 4 && x <= 12);

    cout << (a && b) << " ";
    cout << (a || b) << " ";
    cout << (a && !b || b && !a) << " ";
    cout << (!a && !b) << endl;

    return 0;
}
