#include<iostream>
#include<algorithm>
using namespace std;

int main()
{
	int n, a, b;
	cin >> n;

    int ans = 10001 * 10001;
	for (int i = 0; i < 3; i++)
	{
		cin >> a >> b;
		ans = min(ans, (n / a + bool(n % a)) * b);
	}
	
    cout << ans << endl;

	return 0;
}
