#include<iostream>
using namespace std;
int main()
{
	const int year0 = 2021, month0 = 10, day0 = 9, day_of_week0 = 6;
	char week[7][10] = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
	int days_per_month[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	int year, month, day;
	cout << "Input year, month and day:" << endl;
	cin >> year >> month >> day;
	int days = 0;
	if (year == year0)
	{
		if (month < month0)
		{
			days -= days_per_month[month] - day;  // first month
			for (int i = month + 1; i < month0; i++)  // transitional months
				days -= days_per_month[i];
			days -= day0;  // last month
		}
		else if (month == month0)
			days = day - day0;
		else
		{
			days += days_per_month[month0] - day0;  // first month
			for (int i = month0 + 1; i < month; i++)  // transitional months
				days += days_per_month[i];
			days += day;  // last month
		}
	}
	else if (year < year0)
	{
		// first year
		days -= days_per_month[month] - day;
		for (int i = month + 1; i < 13; i++)
			days -= days_per_month[i];
		if (((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) && month <= 2)
			days -= 1;
		// transitional years
		for (int i = year + 1; i < year0; i++)
			if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
				days -= 366;
			else
				days -= 365;
		// last year
		for (int i = 1; i < month0; i++)
			days -= days_per_month[i];
		days -= day0;
	}
	else
	{
		// first year
		days += days_per_month[month0] - day0;
		for (int i = month0 + 1; i < 13; i++)
			days += days_per_month[i];
		// transitional years
		for (int i = year0 + 1; i < year; i++)
			if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
				days += 366;
			else
				days += 365;
		// last year
		for (int i = 1; i < month; i++)
			days += days_per_month[i];
		if (((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) && month > 2)
			days += 1;
		days += day;
	}
	int day_of_week = (((days + day_of_week0) % 7) + 7) % 7;
	cout << year << "-" << month << "-" << day << " is " << week[day_of_week] << endl;
	return 0;
}