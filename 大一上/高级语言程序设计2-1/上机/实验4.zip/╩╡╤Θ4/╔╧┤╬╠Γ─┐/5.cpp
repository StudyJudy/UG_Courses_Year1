#include<iostream>
using namespace std;
int main()
{
	char str[101] = { 0 };
	cout << "Input a string in 100 characters:" << endl;
	cin.getline(str, 101);
	int i = 0;
	while (str[i] != 0)
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
			str[i] += 32;
		else if (str[i] >= 'a' && str[i] <= 'z')
			str[i] -= 32;
		i++;
	}
	cout << "The result is: " << str << endl;
	return 0;
}