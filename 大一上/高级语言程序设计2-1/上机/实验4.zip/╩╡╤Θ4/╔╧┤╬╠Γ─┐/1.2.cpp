#include<iostream>
using namespace std;
int main()
{
	int x[5], max, min;
	cout << "Input five integers:" << endl;
	for (int i = 0; i < 5; i++)
		cin >> x[i];
	max = min = x[0];
	for (int i = 1; i < 5; i++)
	{
		if (max < x[i])
			max = x[i];
		if (min > x[i])
			min = x[i];
	}
	cout << "The maximum is " << max << endl;
	cout << "The minimum is " << min << endl;
	return 0;
}