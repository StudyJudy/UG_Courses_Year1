#include<iostream>
using namespace std;
int main()
{
	double x, y;
	cout << "Input the value of x:" << endl;
	cin >> x;
	if (x < -1)
		y = 1;
	else if (x >= -1 && x <= 1)
		y = 2 * x + 9;
	else
		y = 5 * x - 3;
	cout << "The value of y is " << y << endl;
	return 0;
}