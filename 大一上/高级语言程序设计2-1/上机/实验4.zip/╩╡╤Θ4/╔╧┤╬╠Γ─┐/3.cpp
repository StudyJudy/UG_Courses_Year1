#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "Input a five-digit number:" << endl;
	cin >> num;
	if ((num % 10 == num / 10000) && (num % 100 / 10 == num % 10000 / 1000))
		cout << num << " is a symmetric number" << endl;
	else
		cout << num << " is not a symmetric number" << endl;
	return 0;
}