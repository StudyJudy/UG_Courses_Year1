#include<iostream>
using namespace std;
int main()
{
	int x1, x2, x3, x4, x5;
    int max, min;
	cout << "Input five integers:" << endl;
	cin >> x1 >> x2 >> x3 >> x4 >> x5;
	max = min = x1;
    if (max < x2) {
        max = x2;
    }
    if (min > x2) {
        min = x2;
    }
    if (max < x3) {
        max = x3;
    }
    if (min > x3) {
        min = x3;
    }
    if (max < x4) {
        max = x4;
    }
    if (min > x4) {
        min = x4;
    }
    if (max < x5) {
        max = x5;
    }
    if (min > x5) {
        min = x5;
    }
	cout << "The maximum is " << max << endl;
	cout << "The minimum is " << min << endl;
	return 0;
}
