#include<iostream>
using namespace std;
int main()
{
	int a, b, c;
	cout << "Input the lengths of three sides (integers):" << endl;
	cin >> a >> b >> c;
	// Sort three sides.
	if (a > b)
	{
		// Swap the value of a and b.
		a = a + b;
		b = a - b;
		a = a - b;
		// The universal way to swap is
		// int t = a;
		// a = b;
		// b = t; 
	}
	if (b > c)
	{
		b = b + c;
		c = b - c;
		b = b - c;
	}
	if (a > b)
	{
		a = a + b;
		b = a - b;
		a = a - b;
	}
	// Now, we have a <= b <= c.
	if (a + b > c)
	{
		cout << "These three sides can make up a triangle, and it's ";
		if (a * a + b * b > c * c)
			cout << "an acute";
		else if (a * a + b * b == c * c)
			cout << "a right";
		else
			cout << "an obtuse";
		if (a == c)  // a == b == c
			cout << "/equilateral";
		else if (a == b || b == c)
			cout << "/isosceles";
		cout << " triangle" << endl;

	}
	else
		cout << "These three sides can not make up a triangle" << endl;
	return 0;
}