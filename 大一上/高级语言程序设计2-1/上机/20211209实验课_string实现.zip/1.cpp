#include<iostream>
#include<string>
using namespace std;
int main() {
	string s;
	cin >> s;
	cout << s.length() << endl;
	cout << s.size() << endl;
	return 0;
}