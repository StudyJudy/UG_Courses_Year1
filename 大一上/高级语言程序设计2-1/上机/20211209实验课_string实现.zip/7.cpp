#include<iostream>
#include<string>
using namespace std;

void select_string(string str_long, string str_short);

int main()
{
    string str_long, str_short;
    cin >> str_long;
    cin >> str_short;
    select_string(str_long, str_short);
    return 0;
}

void select_string(string str_long, string str_short)
{
    const int num_long = str_long.size();
    const int num_short = str_short.length();//���ֲ�ͬ����string���ȵķ���
    int count = 0;
    for (int i = 0; i < num_long - num_short; i++)
    {
        string str_cut = string(str_long, i, num_short);//�±��i��ʼ������Ϊnum_short���Ӵ�
        if (str_cut == str_short)
        {
            count++;
            cout << i << endl;
        }
    }
    cout << count << endl;
}