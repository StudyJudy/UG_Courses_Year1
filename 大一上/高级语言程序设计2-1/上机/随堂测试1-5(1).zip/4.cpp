#include<iostream>
#include<iomanip>
using namespace std;
int main() {
	int year, day, month, a[13], i, days = 0, sum = 0, j, k;
	cin >> year >> day >> month;
	if (day < 1 || day>7 || month < 1 || month>12) { cout << "ERROR"; return 0; }

	if ((year % 100 != 0 && year % 4 == 0) || year % 400 == 0) {
		a[1] = 31; a[2] = 29; a[3] = 31; a[4] = 30; a[5] = 31; a[6] = 30; a[7] = 31; a[8] = 31; a[9] = 30; a[10] = 31; a[11] = 30; a[12] = 31;
	}
	else {
		a[1] = 31; a[2] = 28; a[3] = 31; a[4] = 30; a[5] = 31; a[6] = 30; a[7] = 31; a[8] = 31; a[9] = 30; a[10] = 31; a[11] = 30; a[12] = 31;
	}
	for (i = 1; i < month; i++)
		sum += a[i];
	days = (sum % 7 + day) % 7;


	for (k = 1; k <= days; k++)cout << "    ";
	for (j = 1; j <= a[month]; j++) {

		cout << setw(4) << j;
		if ((j + days) % 7 == 0)cout << endl;
	}

	return 0;
}