#include <iostream>
using namespace std;
int main()
{
	int n, sum = 0;
	int nums[21];
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> nums[i];
		sum += nums[i];
	}
	nums[n] = sum / n;
	for (int i = 0; i < n + 1; i++)
		for (int j = n; j > i; j--)
			if (nums[j] > nums[j - 1])
			{
				int tmp = nums[j];
				nums[j] = nums[j - 1];
				nums[j - 1] = tmp;
			}
	cout << sum / n << endl;
	for (int i = 0; i < n; i++)
		cout << nums[i] << " ";
	cout << nums[n] << endl;
	return 0;
}