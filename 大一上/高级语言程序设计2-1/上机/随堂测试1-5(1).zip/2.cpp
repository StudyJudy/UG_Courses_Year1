#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	const int people_num = 12;
	int k, cur_no = 0, cur_person = 0, people_left = people_num;
	int people[people_num];
	for (int i = 0; i < people_num; i++)
		people[i] = i + 1;
	cin >> k;
	while (people_left > 1)
	{
		if (people[cur_person] == 0)
		{
			cur_person = (cur_person + 1) % people_num;
			continue;
		}
		if (cur_no == k - 1)
		{
			people[cur_person] = 0;
			for (int i = 0; i < people_num; i++)
				cout << setw(3) << people[i];
			cout << endl;
			people_left--;
		}
		cur_no = (cur_no + 1) % k;
		cur_person = (cur_person + 1) % people_num;
	}
	for (int i = 0; i < people_num; i++)
		if (people[i] != 0)
			cout << setw(3) << i + 1 << endl;
	return 0;
}