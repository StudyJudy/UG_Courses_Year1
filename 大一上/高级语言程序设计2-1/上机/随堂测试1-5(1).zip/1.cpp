#include <iostream>
#include <iomanip>
using namespace std;
void print(int days, int first_day)
{
	for (int i = 0; i < first_day; i++)
		cout << setw(4) << "";
	for (int i = 1; i <= days; i++)
	{
		cout << setw(4) << i;
		if ((i + first_day) % 7 == 0)
			cout << endl;
	}
	if ((days + first_day) % 7 != 0)
		cout << endl;
	return;
}
int main()
{
	int year, day, month;
	cin >> year >> day >> month;
	if (day < 0 || day > 6 || month < 1 || month >12)
	{
		cout << "ERROR" << endl;
		return 0;
	}
	int days[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	if (year % 400 == 0 || year % 4 == 0 && year % 100 != 0)
		days[2] = 29;
	for (int i = 1; i < month; i++)
		day = (day + days[i]) % 7;
	print(days[month], day);
	return 0;
}