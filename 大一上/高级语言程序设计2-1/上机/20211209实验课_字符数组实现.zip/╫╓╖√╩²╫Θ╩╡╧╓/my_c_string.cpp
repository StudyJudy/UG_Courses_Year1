/**
 * 字符数组实现字符串常见操作：
 * 字符串长度
 * 字符串连接
 * 字符串复制
 * 字符串比较
 * 字符串中的字符大小写转换
 * 字符串中的字符次数统计
 * 在长字符串中统计短字符串出现的次数，并且统计每一次出现的下标
 *
 * @author Licheng_Xu
 * @date 2021/12/08
 */

#include <iostream>
using namespace std;

// 字符串长度
int strlen(char str[])
{
    int len = 0;
    while (str[len] != '\0')
    {
        len++;
    }
    return len;
}

// 字符串连接
void strcat(char dst[], char src[])
{
    int len = strlen(dst);
    int i = 0;
    while (src[i] != '\0')
    {
        dst[len] = src[i];
        len++;
        i++;
    }
    dst[len] = '\0';
}

// 字符串复制
void strcpy(char src[], char dst[])
{
    int len = 0;
    while (src[len] != '\0')
    {
        dst[len] = src[len];
        len++;
    }
    dst[len] = '\0';
}

// 字符串比较
int strcmp(char s1[], char s2[])
{
    int i = 0;
    while (true)
    {
        if (s1[i] != s2[i])
        {
            return s1[i] < s2[i] ? -1 : 1;
        }
        if (s1[i] == '\0')
        {
            break;
        }
        i++;
    }

    return 0;
}

// 字符串中的字符小写转换
void tolower(char str[])
{
    for (int i = 0; i < strlen(str); i++)
    {
        if (str[i] >= 'A' && str[i] <= 'Z')
        {
            str[i] = str[i] - 'A' + 'a';
        }
    }
}

// 字符串中的字符大写转换
void toupper(char str[])
{
    for (int i = 0; i < strlen(str); i++)
    {
        if (str[i] >= 'a' && str[i] <= 'z')
        {
            str[i] = str[i] - 'a' + 'A';
        }
    }
}

// 字符串中的字符次数统计
void charCount(char str[])
{
    // 用于统计的数组
    int count[128] = { 0 };
    // 逐个统计
    for (int i = 0; i < strlen(str); i++)
    {
        count[str[i]]++;
    }
    // 输出结果
    for (int i = 0; i < 128; i++)
    {
        if (count[i] != 0)
        {
            cout << char(i) << ":" << count[i] << endl;
        }
    }
}

// 在长字符串中统计短字符串出现的次数，并且统计每一次出现的下标
// 字符串查找算法：暴力查找，KMP，BM
void strstr(char str[], char substr[])
{
    int len = strlen(str);
    int sublen = strlen(substr);
    
    int count = 0;
    int *index = new int[len];

    // 逐个对比
    for (int i = 0; i <= len - sublen; i++)
    {
        bool flag = true;
        for (int j = 0; j < sublen; j++)
        {
            if (str[i + j] != substr[j])
            {
                flag = false;
                break;
            }
        }
        if (flag)
        {
            index[count] = i;
            count++;
        }
    }
    // 输出结果
    cout << substr << " 在 " << str << " 中的出现次数为：" << count << endl;
    if (count == 0)
    {
        return;
    }
    cout << "出现的下标分别为：";
    for (int i = 0; i < count; i++)
    {
        cout << index[i];
        if (i != count - 1)
        {
            cout << " ";
        }
        else
        {
            cout << endl;
        }
    }
}

int main()
{
    char src[20] = "world!";
    char dst[20] = "hello, ";

    cout << "strlen: " << strlen(src) << endl;
    cout << "strlen: " << strlen(dst) << endl;

    strcat(dst, src);
    cout << "strcat: " << dst << endl;

    strcpy(src, dst);
    cout << "strcpy: " << dst << endl;

    cout << "strcmp: " << strcmp(src, dst) << endl;

    cout << endl;

    /*** 大小写转换 ***/
    char upperStr[10] = "ABCDEFG";
    tolower(upperStr);
    cout << upperStr << endl;

    char lowerStr[10] = "abcdefg";
    tolower(lowerStr);
    cout << lowerStr << endl;

    cout << endl;
    
    /*** 字符统计 ***/
    cout << "字符统计：" << endl;
    charCount(src);
    cout << endl;

    /*** 字符串查找 ***/
    char str[10] = "abcdabaab";
    char substr[3] = "ab";
    strstr(str, substr);

    return 0;
}
