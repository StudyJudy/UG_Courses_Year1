#include <iostream>
#include <climits>
using namespace std;

int main()
{
    int n;
    cin >> n;
    if (n <= 0)
    {
        cout << "Incorrect input!";
        return 0;
    }
    long long res = 0;
    long long factorial = 1;
    int sign = 1;
    for (int i = 1; i <= n; i++) {
        factorial *= i;
        if (factorial > INT_MAX)
        {
            cout << "Out of range!";
            return 0;
        }
        res += sign * factorial;
        sign = -sign;
    }
    cout << res;
    return 0;
}