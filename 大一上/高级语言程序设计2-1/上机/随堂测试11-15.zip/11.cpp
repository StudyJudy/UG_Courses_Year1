#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	int A[5][5], B[5][5], C[5][5] = { 0 };
	for (int i = 0; i < 5; i++)
		for (int j = 0; j < 5; j++)
			cin >> A[i][j];
	for (int i = 0; i < 5; i++)
		for (int j = 0; j < 5; j++)
			cin >> B[i][j];
	for (int i = 0; i < 5; i++)
		for (int j = 0; j < 5; j++)
			for (int k = 0; k < 5; k++)
				C[i][j] += A[i][k] * B[k][j];
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
			cout << setw(6) << C[i][j];
		cout << endl;
	}
	return 0;
}