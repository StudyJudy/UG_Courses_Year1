#include<iostream>
using namespace std;
int strlen(char[]);
int main()
{
	char S[5000], s[5000];
	cin >> S >> s;
	int i = 0, s_len = strlen(s);
	while (S[i] != 0)
	{
		if (S[i] == s[0])
		{
			int j = 0;
			while (S[i + j] == s[j] && j < s_len)
				j++;
			if (s[j] == 0)
			{
				for (int x = i; x < i + j; x++)
					S[x] = 0;
				i = i + j - 1;
			}
		}
		i++;
	}
	for (int j = 0; j < i; j++)
	{
		if (S[j] != 0)
			cout << S[j];
	}
	cout << endl;
	return 0;
}
int strlen(char m[])
{
	int i = 0;
	while (m[i] != 0)
		i++;
	return i;
}