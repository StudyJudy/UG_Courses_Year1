#include <iostream>
using namespace std;

int main()
{
    int a, b, c;
    int d, e, f;
    int n;
    cin >> a >> b >> c;
    cin >> d >> e >> f;
    cin >> n;
    if (a <= d || d < 0)
    {
        cout << "Incorrect input!" << endl;
        return 0;
    }
    if (b <= e || e < 0)
    {
        cout << "Incorrect input!" << endl;
        return 0;
    }
    if (c <= f || f < 0)
    {
        cout << "Incorrect input!" << endl;
        return 0;
    }
    bool flag = false;
    for (int i = 0; i <= n; i++)
    {
        if (i % a == d && i % b == e && i % c == f)
        {
            flag = true;
            cout << i << " ";
        }
    }
    if (!flag)
    {
        cout << "No solution!" << endl;
    }
    return 0;
}