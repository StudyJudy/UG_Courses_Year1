#include <iostream>
using namespace std;

// 判断是不是闰年
bool isLeap(int year)
{
	return year % 400 == 0 || year % 4 == 0 && year % 100 != 0;
}

int main()
{
	int year, month, day, res = 0;
	cin >> year >> month >> day;

	int days[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	if (isLeap(year))
		days[2] = 29;
	if (month > 12 || month < 1 || day < 1 || day > days[month])
	{
		cout << "WRONG INPUT!" << endl;
		return 0;
	}
	for (int i = 1; i < month; i++)
		res += days[i];
	res += day;

	cout << res << endl;
	return 0;
}