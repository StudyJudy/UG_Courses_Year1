#include <iostream>
#include <cstring>
using namespace std;

struct word
{
    int start; // 单词的起始下标
    int len;   // 单词的长度
};

int main()
{
    // 输入
    char str[100];
    cin.getline(str, 100);
    int length = strlen(str);

    // 逐字符处理
    word max_len_word = {0, 0};
    int cur_len = 0;
    for (int i = 0; i < length; i++)
    {
        if (str[i] == ' ')
        {
            // 空格说明一个单词结束，得到单词的起始下标和长度
            // word.start = i - cur_len;
            // word.len = cur_len;
            // 比较更新最长的单词
            if (max_len_word.len < cur_len)
            {
                max_len_word.start = i - cur_len;
                max_len_word.len = cur_len;
            }
            // 重置单词长度
            cur_len = 0;
        }
        else
        {
            // 不是空格，单词长度加一
            cur_len++;
        }
    }
    // 最后一个单词以 \0 结尾，不以空格结尾，需要单独处理
    if (max_len_word.len < cur_len)
    {
        max_len_word.start = length - cur_len;
        max_len_word.len = cur_len;
    }

    // 输出结果
    for (int i = 0; i < max_len_word.len; i++)
    {
        cout << str[max_len_word.start + i];
    }
    cout << endl;
    return 0;
}