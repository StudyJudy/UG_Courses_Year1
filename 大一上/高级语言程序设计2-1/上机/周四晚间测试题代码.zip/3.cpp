#include <iostream>
using namespace std;

void output1(int nums[10][10], int m, int n)
{
	int dir = 0; // 0：从左到右，1：从右到左
	int i = 0, j = 0;
	int count = m * n;
	while (true)
	{
		if (count == 0)
		{
			cout << endl;
			break;
		}
		if (count > 1)
			cout << nums[i][j] << " ";
		else
			cout << nums[i][j];
		count--;

		if (dir == 0)
		{
			// 从左到右
			if (j == n - 1)
			{
				// 某一行最后一个数，走到下一行并换方向
				i++;
				dir = 1;
			}
			else
			{
				j++;
			}
		}
		else
		{
			// 从右到左
			if (j == 0)
			{
				// 某一行最后一个数，走到下一行并换方向
				i++;
				dir = 0;
			}
			else
			{
				j--;
			}
		}
	}
}

void output2(int nums[10][10], int si, int ei, int sj, int ej, int& count)
{
	// 递归终止条件
	if (count == 0)
	{
		cout << endl;
		return;
	}
	// 最上边那一行，从左到右
	for (int j = sj; j <= ej; j++)
	{
		cout << nums[si][j];
		if (--count > 0)
		{
			cout << " ";
		}
	}
	// 最右边那一列，从上到下
	for (int i = si + 1; i <= ei; i++)
	{
		cout << nums[i][ej];
		if (--count > 0)
		{
			cout << " ";
		}
	}
	// 最下边那一行，从右到左
	for (int j = ej - 1; si < ei && j >= sj; j--)
	{
		cout << nums[ei][j];
		if (--count > 0)
		{
			cout << " ";
		}
	}
	// 最左边那一列，从下到上
	for (int i = ei - 1; sj < ej && i > si; i--)
	{
		cout << nums[i][sj];
		if (--count > 0)
		{
			cout << " ";
		}
	}
	// 缩小一圈，减小问题规模，递归处理
	output2(nums, si + 1, ei - 1, sj + 1, ej - 1, count);
}

int main()
{
	int m, n, nums[10][10];
	cin >> m >> n;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			cin >> nums[i][j];

	output1(nums, m, n);

	int count = m * n;
	output2(nums, 0, m - 1, 0, n - 1, count);

	return 0;
}