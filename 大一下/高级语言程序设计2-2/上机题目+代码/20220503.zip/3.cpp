#include <iostream>
#include <list>
#include <algorithm>

using namespace std;

int main()
{
    int a[6] = {10, 15, 2, 8, 22, 11};
    int b[8] = {1, 5, 10, 22, 4, 8, 33, 6};
    list<int> a_list(a, a + 6);
    list<int> b_list(b, b + 8);
    list<int>::iterator iter;
    // 输出第一个链表
    cout << "第一个list：";
    for (iter = a_list.begin(); iter != a_list.end(); iter++)
        cout << *iter << " ";
    // 输出第二个链表
    cout << endl
         << "第二个list：";
    for (iter = b_list.begin(); iter != b_list.end(); iter++)
        cout << *iter << " ";
    // 输出合并的链表
    cout << endl
         << "合并之后的list：";
    a_list.splice(a_list.end(), b_list);
    for (iter = a_list.begin(); iter != a_list.end(); iter++)
        cout << *iter << " ";
    // 删除重复数据后从小到大排序
    cout << endl
         << "删除重复元素后小到大排序的list：";
    a_list.sort();
    // sort(a_list.begin(), a_list.end());
    a_list.unique();
    for (iter = a_list.begin(); iter != a_list.end(); iter++)
        cout << *iter << " ";
    cout << endl;

    return 0;
}
