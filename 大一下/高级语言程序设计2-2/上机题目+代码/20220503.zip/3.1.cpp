#include <iostream>
#include <list>

using namespace std;

int main()
{
    list<int> a_list = {10, 15, 2, 8, 22, 11};
    list<int> b_list = {1, 5, 10, 22, 4, 8, 33, 6};
    a_list.sort();
    b_list.sort();
    // merge 需要两个 list 有序
    a_list.merge(b_list);
    a_list.unique();
    for (auto it = a_list.begin(); it != a_list.end(); it++)
    {
        cout << *it << " ";
    }
    return 0;
}