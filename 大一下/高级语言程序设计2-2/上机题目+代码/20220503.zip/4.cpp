#include <bits/stdc++.h>
#include <algorithm>
using namespace std;

const int N = 100;

int main()
{
    string s;
    stack<char> st;
    cin >> s;
    for (int i = 0; i < s.size(); i++)
    {
        if (s[i] >= '0' && s[i] <= '9')
            cout << s[i]; // 0-9 直接压入栈中
        else if (s[i] == ')')
        { //遇上右括号依次弹栈，直到遇上左括号
            while (true)
            {
                if (st.top() == '(')
                {
                    st.pop();
                    break;
                }
                cout << st.top(); //栈中的左括号及左括号以上其他符号全部弹出
                st.pop();
            }
        }
        else
        {
            if (!st.empty() && (s[i] == '+' || s[i] == '-') &&
                (st.top() == '*' || st.top() == '/'))
            { //当遇上加减操作时，有两种情况：1、如果栈为空，则直接压入栈中；
                while (!st.empty())
                { //                                2、如果栈不为空，则需要判断与栈顶符号的优先级
                    if (st.top() == '(')
                        break;        //（1）如果栈顶的符号优先级大，依次弹栈直到栈空或者遇上左括号
                    cout << st.top(); //（2）否则，直接压入栈中
                    st.pop();
                }
                st.push(s[i]); //弹栈操作完成后，再把遇上的符号压入栈中
            }
            else
                st.push(s[i]);
        }
    }
    while (!st.empty())
    {
        cout << st.top();
        st.pop();
    }
    return 0;
}

/*9+(3-1)*3+4/2*/
