#include <iostream>
#include <string>
#include <map>

using namespace std;

int main()
{
    map<string, int> word_count; // empty
    string word;

    while (cin >> word)
    {
        if (!isalnum(word.back()))
        {
            word.pop_back();
        }
        ++word_count[word]; // 用下标访问
    }

    map<string, int>::iterator iter; // iter 为 pair 类型(value_type)
    for (iter = word_count.begin(); iter != word_count.end(); iter++)
    {
        cout << "[" << iter->first << "] = " << iter->second << endl;
    }

    return 0;
}
