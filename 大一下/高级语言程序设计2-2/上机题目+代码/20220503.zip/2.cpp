#include <iostream>
#include <deque>
#include <vector>
#include <string>
#include <algorithm>
#include <iomanip>

using namespace std;

// 构造Player类
class Player
{
public:
    Player() {}
    ~Player() {}
    // 设置分数
    void setScore(double s) { score = s; }
    // 设置名字
    void setName(const string &n)
    {
        name = n;
    }
    // 获取分数
    double getScore() { return score; }
    // 获取名字
    string getName() { return name; }

private:
    // 最终得分
    double score;
    // 名字
    string name;
};

// 创建比较函数
bool sortPlayer(Player &a, Player &b)
{
    return a.getScore() > b.getScore();
}

// 创建展示函数
void Display(vector<Player> &vec)
{
    cout << endl
         << "  *** Final Result *** " << endl;
    int size = vec.size();
    cout.setf(ios::left);
    for (int i = 0; i < size; i++)
        cout << "Name: " << setw(10) << vec[i].getName() << "Score: " << vec[i].getScore() << endl;
}

int main()
{
    vector<Player> players;
    for (int i = 0; i < 5; i++)
    {
        Player player;
        string name;
        cin >> name;
        // 设置姓名
        player.setName(name);
        // 利用双端队列保存10个数据
        deque<double> scores;
        for (int j = 0; j < 10; j++)
        {
            double s;
            cin >> s;
            scores.push_back(s);
        }
        // 进行排序
        sort(scores.begin(), scores.end());
        // 去除最高分和最低分
        scores.pop_back();
        scores.pop_front();
        double total_score = 0;
        // 求总分
        for (auto iter = scores.begin(); iter != scores.end(); iter++)
            total_score += *iter;
        // 设置分数
        player.setScore(total_score / 8);
        players.push_back(player);
    }
    // 对vector进行排序，自定义规则sortPlayer函数
    sort(players.begin(), players.end(), sortPlayer);
    // 展示最后结果
    Display(players);
    return 0;
}
