#include <vector>
#include <iostream>
#include <cstring>
#include <map>
using namespace std;

int main()
{
    string s;
    char c;
    while (cin >> s >> c)
    {
        string::iterator it;

        vector<int> v;
        for (it = s.begin(); it != s.end(); ++it)
        {
            if (*it == c)
            {
                v.push_back(it - s.begin() + 1);
            }
        }

        if (!v.empty())
        {
            vector<int>::iterator l;
            for (l = v.begin(); l != v.end(); l++)
            {
                cout << *l << " ";
            }
            cout << endl;
        }
        else
        {
            //如果vector为空，说明没有相应位置
            cout << "NO" << endl;
        }
    }
    return 0;
}
