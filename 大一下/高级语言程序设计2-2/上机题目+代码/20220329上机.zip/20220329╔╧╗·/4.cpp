#include <iostream>
using namespace std;
class vehicle
{
public:
    vehicle(int m, int w) : maxspeed(m), weight(w){}
    vehicle(){}
    ~vehicle(){}
    void run()
    {
        cout << "run" << endl;
    }
    void stop()
    {
        cout << "stop" << endl;
    }

private:
    int maxspeed;
    int weight;
};

class bicycle : virtual public vehicle
{
public:
    bicycle(int w, int m, int h) : vehicle(w, m), height(h){}
    bicycle(){}
    ~bicycle(){}
    void getht()
    {
        cout << "高度:" << height << endl;
    }

private:
    int height;
};

class motorcar : virtual public vehicle
{
public:
    motorcar(int w, int m, int s) : vehicle(w, m), seatnum(s){}
    motorcar(){}
    ~motorcar(){}
    void getsm()
    {
        cout << "座位数量:" << seatnum << endl;
    }

private:
    int seatnum;
};

class motorcycle : public bicycle, public motorcar
{
public:
    motorcycle(int w, int m, int h, int s) : bicycle(w, m, h), motorcar(w, m, s){}
    motorcycle(){}
    // bicycle::maxspeed = m;
    ~motorcycle(){}
};

int main()
{
    motorcycle m(30, 20, 2, 7);
    m.getht();
    m.getsm();
    m.run();
    m.stop();
    return 0;
}