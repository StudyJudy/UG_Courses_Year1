#include <iostream>
// #include <math.h>
using namespace std;

class Mammal
{
protected:
    int itsAge;
    int itsWeight;

public:
    Mammal(int age, int weight): itsAge(age), itsWeight(weight) {cout<<"Constructor in Mammal(yes)"<<endl;}
    Mammal(){cout<<"Constructor in Mammal"<<endl;}
    ~Mammal(){cout<<"Destructor in Mammal"<<endl;}
    int GetAge() { return itsAge; }
    void SetAge(int age) { itsAge = age; }
    int GetWeight() { return itsWeight; }
    void SetWeight(int weight) { itsWeight = weight; }
};

class Dog : public Mammal
{
private:
    string itsColor;

public:
    Dog(int age, int weight, string color):Mammal(age,weight), itsColor(color) {cout<<"Constructor in Dog(yes)"<<endl;}
    Dog() : Mammal() {cout<<"Constructor in Dog"<<endl;}
    ~Dog(){cout<<"Destructor in Dog"<<endl;}

    string GetColor() { return itsColor; }
    void SetColor(string color) { itsColor = color; }
};

int main()
{
    Dog d;
    d.SetAge(4);
    d.SetWeight(12);
    d.SetColor("Black");
    cout<<d.GetAge()<<endl;
    cout<<d.GetWeight()<<endl;
    cout<<d.GetColor()<<endl;
    return 0;
}
