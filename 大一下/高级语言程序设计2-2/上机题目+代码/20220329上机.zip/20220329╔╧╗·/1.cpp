#include <iostream>
#include<string.h>
using namespace std;

class Person
{
    int id;
    string name;
public:
    Person(int pid, string pname) : id(pid), name(pname) {}
    Person() {}
    virtual void set();
    virtual void show();
    ~Person() {}
};

void Person::show()
{
    cout << "id: " << id << endl;
    cout << "name: " << name << endl;
}

void Person::set()
{
    int id;
    string name;
    cout << "请输入编号: ";
    cin >> this->id;
    cout << "请输入姓名: ";
    cin >> this->name;
}

class Student: public Person{   // 派生类, 公有继承+虚函数
public:
    Student(int sid, string sname, string scla, int sscore):Person(sid, sname), clas(scla), score(sscore) {}
    Student() {}
    virtual void set();  // 不用定义
    virtual void show();
    ~Student() {}
private:
    string clas;
    int score;
};

void Student::show()
{
    Person::show();   // 私有变量的访问
    cout << "class: " << clas << endl;
    cout << "score: " << score << endl;
}

void Student::set()
{
    int id;
    string name;
    string cla;
    int score;
    Person::set();  // 私有变量的访问
    cout << "请输入学生班级: ";
    cin >> this->clas;
    cout << "请输入学生成绩: ";
    cin >> this->score;
}


class Teacher: public Person{   // 派生类, 公有继承+虚函数
public:
    Teacher(int tid, string tname, string t, string depart):Person(tid, tname), title(t), department(depart) {}
    Teacher() {}
    virtual void set();
    virtual void show();
    ~Teacher() {}
private:
    string title;
    string department;
};

void Teacher::show()
{
    Person::show();   // 私有变量的访问
    cout << "title: " << title << endl;
    cout << "department: " << department << endl;
}

void Teacher::set()
{
    int id;
    string name;
    string title;
    string department;
    Person::set();  // 私有变量的访问
    cout << "请输入老师职称: ";
    cin >> this->title;
    cout << "请输入老师部门: ";
    cin >> this->department;
}

 // Person p;
    // point=&p;
    // point->set();  // 输入函数
    // point->show();  // 输出函数

int main()
{
    Person* point= NULL;

    Student s;
    point=&s;
    point->set();  // 输入函数
    point->show();  // 输出函数

    Teacher t;
    point=&t;
    point->set();  // 输入函数
    point->show();  // 输出函数
    return 0;
}