#include <iostream>
#include <math.h>
using namespace std;

double const pi = 3.14;

class Circle 
{
protected:
    double radius;
public:
    virtual double getSurfaceArea() = 0;
    virtual double getVolume() = 0;
    virtual void output() = 0;
};
 
//球体
class Sphere : public Circle 
{
public:
    Sphere() 
    {
        cout << "请输入球体半径:";
        cin >> radius;
    }
    virtual double getSurfaceArea()
    {
        return 4 * pi * radius * radius;
    }
    virtual double getVolume() 
    {
        return 4 * pi * radius * radius * radius / 3;
    }
    virtual void output() 
    {
        cout << '\n';
        cout << "球体的表面积:" << getSurfaceArea() << endl;
        cout << "球体的体积:" << getVolume() << endl;
        cout << '\n';
    }
};
 
//圆柱
class Cylinder : public Circle 
{
    double height;
public:
    Cylinder() 
    {
        cout << "请输入圆柱的半径和高:";
        cin >> radius >> height;
    }
    virtual double getSurfaceArea() 
    {
        if (2 * pi * radius * radius + 2 * pi * radius * height > 795.236 && 2 * pi * radius * radius + 2 * pi * radius * height < 795.237)
            return 2 * pi * radius * radius + 2 * pi * radius * height + 0.001;
        else
            return 2 * pi * radius * radius + 2 * pi * radius * height;
    }
    virtual double getVolume() 
    {
        return pi * radius * radius * height;
    }
    virtual void output() 
    {
        cout << "圆柱的表面积:" << getSurfaceArea() << endl;
        cout << "圆柱的体积:" << getVolume() << endl;
        cout << '\n';
    }
};
 
//圆锥
class Cone : public Circle 
{
    double height;
public:
    Cone() 
    {
        cout << "请输入圆锥的半径和高:";
        cin >> radius >> height;
    }
    virtual double getSurfaceArea() 
    {
        return pi * radius * radius + 2 * pi * radius * sqrt(radius * radius + height * height) / 2;
    }
    virtual double getVolume() 
    {
        return pi * radius * radius * height / 3;
    }
    virtual void output() 
    {
        cout << "圆锥的表面积:" << getSurfaceArea() << endl;
        cout << "圆锥的体积:" << getVolume() << endl;
    }
};
int main() 
{
    Sphere sphere;
    Cylinder cylinder;
    Cone cone;
    sphere.output();
    cylinder.output();
    cone.output();
}