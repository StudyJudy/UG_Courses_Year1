#include <iostream>
using namespace std;

struct ListNode
{
    int val;
    ListNode* next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode* next) : val(x), next(next) {}
};

ListNode* convertNumberToReversedList(int num)
{
    if (num == 0)
    {
        return new ListNode(0);
    }
    ListNode* head = nullptr, * tail = nullptr;
    while (num != 0)
    {
        if (head == nullptr)
        {
            head = tail = new ListNode(num % 10);
        }
        else
        {
            tail->next = new ListNode(num % 10);
            tail = tail->next;
        }
        num /= 10;
    }
    return head;
}

int convertReversedListToNumber(ListNode* head)
{
    if (head == nullptr)
    {
        return 0;
    }
    int num = 0;
    int index = 1;
    while (head != nullptr)
    {
        num += head->val * index;
        head = head->next;
        index *= 10;
    }
    return num;
}

ListNode* addTwoNumbers(ListNode* l1, ListNode* l2)
{
    ListNode* head = nullptr, * tail = nullptr;
    int carry = 0; // �ӷ���λ
    while (l1 || l2)
    {
        // �����һ��Ϊ�գ�˵����λû�����֣�������
        int n1 = l1 != nullptr ? l1->val : 0;
        int n2 = l2 != nullptr ? l2->val : 0;
        int sum = n1 + n2 + carry;
        if (head == nullptr)
        {
            // ��һ����㵥������
            head = tail = new ListNode(sum % 10);
        }
        else
        {
            // β�������½���㣬βָ��ָ���µ�β���
            tail->next = new ListNode(sum % 10);
            tail = tail->next;
        }
        carry = sum / 10;
        // ������һλ
        if (l1 != nullptr)
        {
            l1 = l1->next;
        }
        if (l2 != nullptr)
        {
            l2 = l2->next;
        }
    }
    // �������н�λ���������λ
    if (carry > 0)
    {
        tail->next = new ListNode(carry);
    }
    return head;
}

int main()
{
    int a, b;
    cin >> a >> b;
    ListNode* la = convertNumberToReversedList(a);
    ListNode* lb = convertNumberToReversedList(b);
    ListNode* ls = addTwoNumbers(la, lb);
    cout << convertReversedListToNumber(ls) << endl;

    return 0;
}