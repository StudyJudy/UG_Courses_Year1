﻿#include <iostream>
using namespace std;

class Foo
{
public:
	Foo(int bar = 0) : bar(bar)
	{
		cout << "调用构造函数" << endl;
	}

	Foo(const Foo& foo)
	{
		cout << "调用拷贝构造函数" << endl;
		bar = foo.bar;
	}

	~Foo()
	{
		cout << "调用析构函数" << endl;
	}

	Foo& operator=(const Foo& foo)
	{
		cout << "调用赋值运算符" << endl;
		this->bar = foo.bar;
		return *this;
	}

private:
	int bar;
};

Foo buildFoo()
{
	cout << "buildFoo" << endl;
	Foo* foo = new Foo();
	return *foo;
}

Foo& buildFooRefence()
{
	cout << "buildFooRefence" << endl;
	Foo* foo = new Foo();
	return *foo;
}

void testFoo(Foo foo)
{
	cout << "testFoo" << endl;
}

void testFooReference(Foo &foo)
{
	cout << "testFooReference" << endl;
}

Foo copy(Foo foo)
{
	return foo;
}

int main()
{
	Foo f1, f2(3);
	Foo f3 = f1;
	Foo f4(f2);
	f2 = f1;
	
	cout << endl << "*** Foo f5 = buildFoo(); ****************" << endl;

	Foo f5 = buildFoo();

	cout << endl << "*** f5 = buildFoo(); ********************" << endl;

	f5 = buildFoo();
	cout << endl << "*** Foo &f6 = buildFooRefence(); ********" << endl;

	Foo &f6 = buildFooRefence();
	
	cout << endl << "*** testFoo(f1); ************************" << endl;

	testFoo(f1);

	cout << endl << "*** testFooReference(f1); **************" << endl;

	testFooReference(f1);
	
	cout << endl << "*** Foo f7 = copy(f1); ******************" << endl;

	Foo f7 = copy(f1);

	cout << endl << "*** f7 = copy(f1); **********************" << endl;

	f7 = copy(f1);

	cout << endl << "*************************" << endl;
	return 0;
}
