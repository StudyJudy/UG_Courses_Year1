#include <iostream>
#include "linked_list.h"
#include "stack.h"
#include "queue.h"

using namespace std;

const char* digit = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

// ʮ����תN����
char* decToNBase(int dec, int base)
{
    Stack stack(INT32_MAX);
    while (dec / base != 0)
    {
        stack.push(dec % base);
        dec /= base;
    }
    stack.push(dec);

    char* res = new char(stack.size() + 1);
    int index = 0;
    while (!stack.isEmpty())
    {
        res[index++] = digit[stack.top()];
        stack.pop();
    }
    res[index] = '\0';

    return res;
}

int main()
{
    // ��������
    cout << "��������" << endl;

    LinkedList list;
    for (int i = 0; i < 10; i++)
    {
        list.push_back(i);
    }
    list.print();
    cout << endl;
    list.clear();
    list.print();
    cout << endl;
    for (int i = 0; i < 10; i++)
    {
        list.push_front(i);
    }
    list.print();
    cout << endl;



    // ջ����
    cout << "ջ����" << endl;

    Stack stack;
    stack.push(1);
    stack.push(2);
    stack.push(3);
    while (!stack.isEmpty())
    {
        cout << stack.top() << " ";
        stack.pop();
    }
    cout << endl;


    // ���в���
    cout << "���в���" << endl;

    Queue queue;
    queue.push(1);
    queue.push(2);
    queue.push(3);
    while (!queue.isEmpty())
    {
        cout << queue.front() << " ";
        queue.pop();
    }
    cout << endl;

    // ����ջʵ�ֽ���ת��
    int dec, base;
    cin >> dec >> base;
    char* num = decToNBase(dec, base);
    cout << dec << " = " << num << "(" << base << ")" << endl;

    return 0;
}