#include "linked_list.h"
#include <iostream>

LinkedList::LinkedList()
{
    head = new Node();
    tail = head;
    count = 0;
}

LinkedList::~LinkedList()
{
    clear();
    delete head;
}

void LinkedList::push_front(int val)
{
    Node* node = new Node(val, head->next);
    head->next = node;
    count++;
    // ������ͷ������Ҫ��������βָ��
    if (count == 1)
    {
        tail = node;
    }

}

void LinkedList::push_back(int val)
{
    Node* node = new Node(val);
    tail->next = node;
    tail = node;
    count++;
}

void LinkedList::insertAtIndex(int index, int val)
{
    if (index > count)
    {
        return;
    }
    // ������������ĩβ����������⴦�� tail ָ��
    if (index == count)
    {
        push_back(val);
        return;
    }
    int t = 0;
    Node* curr = head;
    while (t < index)
    {
        curr = curr->next;
        t++;
    }
    Node* node = new Node(val, curr->next);
    curr->next = node;
    count++;
}

void LinkedList::pop_front()
{
    if (count == 0)
    {
        return;
    }
    Node* temp = head->next;
    if (temp == tail)
    {
        // ɾ���ĸպ���β���
        tail = head;
    }
    head->next = temp->next;
    delete temp;
    count--;
}

void LinkedList::pop_back()
{
    if (count == 0)
    {
        return;
    }
    Node* curr = head;
    while (curr->next != tail)
    {
        curr = curr->next;
    }
    delete tail;
    tail = curr;
    tail->next = nullptr;
    count--;
}

void LinkedList::deleteByValue(int val)
{
    if (count == 0)
    {
        return;
    }
    Node* curr = head;
    while (curr->next != nullptr && curr->next->val != val)
    {
        curr = curr->next;
    }
    if (curr->next != nullptr)
    {
        // ˵�� curr->next->val == val��curr->next ����Ҫɾ���Ľ��
        Node* temp = curr->next;
        if (temp == tail)
        {
            // ɾ���ĸպ���β���
            tail = curr;
        }
        curr->next = temp->next;
        delete temp;
    }
}

void LinkedList::deleteByIndex(int index)
{
    if (count == 0 || index >= count)
    {
        return;
    }
    int t = 0;
    Node* curr = head;
    while (t < index)
    {
        t++;
        curr = curr->next;
    }
    // ��ʱ curr ָ��� index - 1 ����㣬curr->next ����Ҫɾ���Ľ��
    Node* temp = curr->next;
    if (temp == tail)
    {
        // ɾ���ĸպ���β���
        tail = curr;
    }
    curr->next = temp->next;
    delete temp;
}

int LinkedList::front()
{
    if (count == 0)
    {
        return -1;
    }
    return head->next->val;
}

int LinkedList::back()
{
    if (count == 0)
    {
        return -1;
    }
    return tail->val;
}

int LinkedList::findIndexByValue(int val)
{
    int t = 0;
    Node* curr = head->next;
    while (curr != nullptr)
    {
        if (curr->val == val)
        {
            return t;
        }
        t++;
        curr = curr->next;
    }
    return -1;
}

int LinkedList::findValueByIndex(int index)
{
    if (index >= count)
    {
        return -1;
    }
    int t = 0;
    Node* curr = head->next;
    while (t < index)
    {
        t++;
        curr = curr->next;
    }
    return curr->val;
}

int LinkedList::size()
{
    return count;
}

bool LinkedList::isEmpty()
{
    return count == 0;
}

void LinkedList::print()
{
    std::cout << "list: (";
    Node* curr = head->next;
    while (curr != nullptr)
    {
        std::cout << curr->val;
        if (curr != tail)
        {
            std::cout << ", ";
        }
        curr = curr->next;
    }
    std::cout << ")";
}

void LinkedList::clear()
{
    while (count != 0)
    {
        pop_front();
    }
}
