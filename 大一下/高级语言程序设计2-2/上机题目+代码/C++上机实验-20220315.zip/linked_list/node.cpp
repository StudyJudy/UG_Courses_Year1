#include "node.h"

Node::Node(int val, Node* next)
{
    this->val = val;
    this->next = next;
}

Node::~Node()
{
}


