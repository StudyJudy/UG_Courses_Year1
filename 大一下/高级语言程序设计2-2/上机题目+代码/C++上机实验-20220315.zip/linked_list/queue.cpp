#include "queue.h"

Queue::Queue(int capacity) : capacity(capacity)
{
}

Queue::~Queue()
{
}
bool Queue::push(int val)
{
    if (queue.size() >= capacity)
    {
        return false;
    }
    queue.push_back(val);
    return true;
}

bool Queue::pop()
{
    if (queue.isEmpty())
    {
        return false;
    }
    queue.pop_front();
    return true;
}

int Queue::front()
{
    return queue.front();
}

int Queue::back()
{
    return queue.back();
}

int Queue::size()
{
    return queue.size();
}

bool Queue::isEmpty()
{
    return queue.isEmpty();
}

bool Queue::isFull()
{
    return queue.size() == capacity;
}

void Queue::clear()
{
    queue.clear();
}
