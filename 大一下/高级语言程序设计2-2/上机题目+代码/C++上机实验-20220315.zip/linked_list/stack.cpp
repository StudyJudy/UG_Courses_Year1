#include "stack.h"

Stack::Stack(int capacity) : capacity(capacity)
{
}

Stack::~Stack()
{
}

bool Stack::push(int val)
{
    if (stack.size() >= capacity)
    {
        return false;
    }
    stack.push_back(val);
    return true;
}

bool Stack::pop()
{
    if (stack.isEmpty())
    {
        return false;
    }
    stack.pop_back();
    return true;
}

int Stack::top()
{
    return stack.back();
}

int Stack::size()
{
    return stack.size();
}

bool Stack::isEmpty()
{
    return stack.isEmpty();
}

bool Stack::isFull()
{
    return stack.size() == capacity;
}

void Stack::clear()
{
    stack.clear();
}
