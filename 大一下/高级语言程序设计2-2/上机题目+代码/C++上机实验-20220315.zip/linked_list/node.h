#pragma once

class Node
{
public:
    int val;
    Node* next;
    Node(int val = -1, Node* next = nullptr);
    ~Node();
};