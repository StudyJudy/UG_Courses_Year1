#include <iostream>
#include <cmath>
#include <utility>
using namespace std;

int gcd(int m, int n)
{
    int t = 1;
    while (t != 0)
    {
        t = m % n;
        m = n;
        n = t;
    }
    return m;
}

class Frac
{
public:
    Frac();
    Frac(int n, int d);
    pair<Frac, Frac> reductToComDen(Frac f); //（a，b）
    Frac reciprocal();
    char comp(Frac f);

    Frac operator+(Frac f);
    Frac operator-(Frac f);
    Frac operator*(Frac f);
    Frac operator/(Frac f);
    bool operator>(Frac f);
    bool operator<(Frac f);
    bool operator==(Frac f);
    Frac& operator=(Frac f);

    friend ostream& operator<<(ostream& out, const Frac& f);
    friend istream& operator>>(istream& in, Frac& f);

private:
    int num;
    int den;
};

Frac::Frac()
{
    num = 0;
    den = 1;
}

Frac::Frac(int n, int d)
{
    int g = gcd(n, d);
    num = n / g;
    den = d / g;
}

pair<Frac, Frac> Frac::reductToComDen(Frac f)
{
    int g = gcd(this->den, f.num);
    Frac f1, f2;
    f1.num = this->num * f.den / g;
    f1.den = this->den * f.den / g;
    f2.num = f.num * this->den / g;
    f2.den = f.den * this->den / g;
    return make_pair(f1, f2);
}

Frac Frac::reciprocal()
{
    return Frac(this->den, this->num);
}

Frac Frac::operator+(Frac f)
{
    int a = this->num * f.den + f.num * this->den;
    int b = this->den * f.den;
    return Frac(a, b);
}

Frac Frac::operator-(Frac f)
{
    int a = this->num * f.den - f.num * this->den;
    int b = this->den * f.den;
    return Frac(a, b);
}

Frac Frac::operator*(Frac f)
{
    int a = this->num * f.num;
    int b = this->den * f.den;
    return Frac(a, b);
}

Frac Frac::operator/(Frac f)
{
    int a = this->num * f.den;
    int b = this->den * f.num;
    return Frac(a, b);
}

Frac& Frac::operator=(Frac f)
{
    this->num = f.num;
    this->den = f.den;
    return *this;
}

bool Frac::operator>(Frac f)
{
    int a = this->num * f.den;
    int b = this->den * f.num;
    return a > b;
}

bool Frac::operator<(Frac f)
{
    int a = this->num * f.den;
    int b = this->den * f.num;
    return a < b;
}

bool Frac::operator==(Frac f)
{
    int a = this->num * f.den;
    int b = this->den * f.num;
    return a == b;
}

char Frac::comp(Frac f)
{
    if (*this > f)
        return '>';
    else if (*this < f)
        return '<';
    else
        return '=';
}

ostream& operator<<(ostream& out, const Frac& f)
{
    if (f.den == 0)
    {
        out << "分母不能为零！";
        return out;
    }
    if (f.den == 1)
    {
        out << f.num;
        return out;
    }
    if (f.num == 0)
    {
        out << 0;
        return out;
    }
    out << f.num << "/" << f.den;
    return out;
}

istream& operator>>(istream& in, Frac& f)
{
    char ch;
    int a, b;
    cin >> a >> ch >> b;
    int g = gcd(a, b);
    f.num = a / g;
    f.den = b / g;
    return cin;
}

int main()
{
    int n;
    Frac a, b;
    cin >> n >> a >> b;

    for (int i = 0; i < n; i++)
    {
        int opt;
        cin >> opt;
        switch (opt)
        {
        case 1:
            cout << a + b << endl;
            break;
        case 2:
            cout << a - b << endl;
            break;
        case 3:
            cout << a * b << endl;
            break;
        case 4:
            cout << a / b << endl;
            break;
        case 5:
        {
            pair<Frac, Frac> res = a.reductToComDen(b);
            cout << res.first << " " << res.second << endl;
        }
        break;
        case 6:
            cout << a.comp(b) << endl;
            break;
        case 7:
            cout << a << endl;
            break;
        case 8:
            cout << a.reciprocal() << endl;
        }
    }
    return 0;
}

