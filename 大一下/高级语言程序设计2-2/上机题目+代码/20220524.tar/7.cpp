#include <iostream>
#include <cstring>
using namespace std;

class Circle
{
protected:
    int r;

public:
    Circle(int _r) : r(_r) {}
    virtual int getV() = 0;
};

class Cylinder : public Circle
{
    int h;

public:
    Cylinder(int _r, int _h) : Circle(_r), h(_h) {}
    int getV()
    {
        return r * r * h;
    }
};

class Cone : public Circle
{
    int h;

public:
    Cone(int _r, int _h) : Circle(_r), h(_h) {}
    int getV()
    {
        return r * r * h / 3;
    }
};

class Ball : public Circle
{
public:
    Ball(int _r) : Circle(_r) {}
    int getV()
    {
        return r * r * r * 4 / 3;
    }
};

int main()
{
    int n;
    cin >> n;
    Circle *c;
    while (n-- > 0)
    {
        int type;
        cin >> type;
        if (type == 1)
        {
            int r, h;
            cin >> r >> h;
            c = new Cylinder(r, h);
            cout << c->getV() << endl;
        }
        if (type == 2)
        {
            int r, h;
            cin >> r >> h;
            c = new Cone(r, h);
            cout << c->getV() << endl;
        }
        if (type == 3)
        {
            int r;
            cin >> r;
            c = new Ball(r);
            cout << c->getV() << endl;
        }
    }
    return 0;
}