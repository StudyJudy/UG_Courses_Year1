#include <iostream>
#include <list>
#include <iterator>
using namespace std;

int main()
{
    int n, m;
    cin >> n >> m;
    int* A = new int[n];
    for (int i = 0; i < n; i++)
    {
        cin >> A[i];
    }
    list<int> queue;
    int t;
    cin >> t;
    while (t-- > 0)
    {
        char op[5];
        cin >> op;
        if (op[1] == 'u')
        {
            int x;
            cin >> x;
            bool found = false;
            // 从后往前找同一组的
            for (auto it = rbegin(queue); it != rend(queue); it++)
            {
                if (A[*it] == A[x])
                {
                    // 3 需要插入到 (2 0) 中 2 的后面
                    // 正向迭代器指向2：(2 0) -> insert(it, 3)        -> (3 2 0)
                    // 反向迭代器指向2：(2 0) -> insert(it.base(), 3) -> (2 3 0)
                    // https://blog.csdn.net/wangdamingll/article/details/53610491
                    queue.insert(it.base(), x);
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                queue.push_back(x);
            }
        }
        else
        {
            cout << queue.front() << endl;
            queue.pop_front();
        }
    }
}