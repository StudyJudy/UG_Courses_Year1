#include <iostream>
#include <cmath>
#include <cstring>

using namespace std;

class Student
{
public:
	char name[20];
	int num;
	Student() {}
	Student(char name[20], int num)
	{
		strcpy(this->name, name);
		this->num = num;
	}
	Student(const Student &stu)
	{
		strcpy(name, stu.name);
		num = stu.num;
	}
	friend ostream &operator<<(ostream &out, Student &stu)
	{
		out << stu.name << endl;
		return out;
	}
	friend bool operator<(Student stu1, Student stu2)
	{
		if (stu1.num > stu2.num)
			return false;
		return true;
	}
	friend bool operator>(Student stu1, Student stu2)
	{
		if (stu1.num < stu2.num)
			return false;
		return true;
	}
};

template <class T>
class Node
{
public:
	T data;
	Node *next;
	Node(T data)
	{
		this->data = data;
	}
};

template <class T>
class List
{
public:
	Node<T> *head, *tail;
	List()
	{
		head = tail = NULL;
	}
	void insert(T data)
	{
		Node<T> *p = new Node<T>(data);
		if (head == NULL)
		{
			head = tail = p;
			tail->next = NULL;
		}
		else
		{
			if (p->data < head->data)
			{
				p->next = head;
				head = p;
			}
			else if (p->data > tail->data)
			{
				tail->next = p;
				tail = p;
				tail->next = NULL;
			}
			else
			{
				Node<T> *temp = head;
				while (temp->next != NULL)
				{
					if (p->data > temp->data && p->data < temp->next->data)
					{
						p->next = temp->next;
						temp->next = p;
						break;
					}
					temp = temp->next;
				}
			}
		}
	}
	void output()
	{
		Node<T> *p = head;
		while (p != NULL)
		{
			cout << p->data;
			p = p->next;
		}
	}
};

int main()
{
	char name[20];
	int num;
	List<Student> list;
	while (cin >> name >> num) // 输入若干行，使用这种方式。windows的控制台下，按 ctrl + z 回车可以结束输入。
	{
		Student stu(name, num);
		list.insert(stu);
	}
	list.output();
}
