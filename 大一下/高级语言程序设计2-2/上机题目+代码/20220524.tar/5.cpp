#include <iostream>
using namespace std;

template <typename T>
void print(T a[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << a[i];
        if (i != n - 1)
        {
            cout << ", ";
        }
    }
    cout << endl;
}

// 每次选择出尚未排序元素中最小的元素放在对应的位置上
template<class T>
void selectSort(T a[], int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        int min = i;
        for (int j = i + 1; j < n; j++)
        {
            if (a[j] < a[min])
            {
                min = j;
            }
        }
        swap(a[i], a[min]);
        print(a, n);
    }
}

int main()
{
    int *a1 = new int[5] {1, 2, 6, 3, 2};
    selectSort(a1, 5);
    cout << endl;

    float a2[5] {3.0f, 4.2f, 1.6f, 2.2f, 6.4f};
    selectSort(a2, 5);
    cout << endl;

    double *a3 = new double[5] {3.0, 4.2, 1.6, 2.2, 6.4};
    selectSort(a3, 5);
    cout << endl;
}