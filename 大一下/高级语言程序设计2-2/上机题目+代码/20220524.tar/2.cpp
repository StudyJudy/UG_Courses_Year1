#include <iostream>
#include <cmath>
using namespace std;

class Shape
{
public:
    virtual double GetArea() = 0;
    virtual double GetPerimeter() = 0;
};

class Circle : public Shape
{
public:
    Circle(int r)
    {
        m_r = r;
    }
    virtual double GetArea()
    {
        return 3.14 * m_r * m_r;
    }
    virtual double GetPerimeter()
    {
        return 2 * 3.14 * m_r;
    }
    double operator-(Circle c)
    {
        double s1, s2;
        s1 = this->GetArea();
        s2 = c.GetArea();
        if (s1 * s2 == 0)
        {
            return 0;
        }
        else
        {
            return (s1 > s2 ? s1 - s2 : s2 - s1);
        }
    }

private:
    int m_r;
};

class Rectangle : public Shape
{
public:
    Rectangle(int w, int h)
    {
        m_w = w;
        m_h = h;
    }
    virtual double GetArea()
    {
        return m_w * m_h;
    }
    virtual double GetPerimeter()
    {
        if (m_w * m_h != 0)
            return 2 * (m_w + m_h);
        else
            return 0;
    }

private:
    int m_w;
    int m_h;
};

int main()
{
    double r1, r2, a, b;
    cin >> r1 >> r2 >> a >> b;

    Circle circle1(r1), circle2(r2);
    Shape *rectangle = new Rectangle(a, b);

    cout << circle1.GetArea() << " ";
    cout << circle1.GetPerimeter() << endl;
    cout << rectangle->GetArea() << " ";
    cout << rectangle->GetPerimeter() << endl;
    cout << circle1 - circle2 << endl;
    return 0;
}
