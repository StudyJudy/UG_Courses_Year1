#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <cmath>
using namespace std;

class Matrix
{
private:
	int array[3][3];

public:
	Matrix()
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				array[i][j] = 0;
			}
		}
	}
	Matrix(int a[3][3]);
	friend ostream& operator<<(ostream&, const Matrix&);
	friend Matrix operator+(Matrix m1, Matrix m2);
	friend Matrix operator-(Matrix m1, Matrix m2);
	friend Matrix operator*(Matrix m1, Matrix m2);
};

Matrix::Matrix(int a[3][3])
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			this->array[i][j] = a[i][j];
		}
	}
}

Matrix operator+(Matrix m1, Matrix m2)
{
	Matrix m;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			m.array[i][j] = m1.array[i][j] + m2.array[i][j];
		}
	}
	return m;
}

Matrix operator-(Matrix m1, Matrix m2)
{
	Matrix m;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
		{
			m.array[i][j] = m1.array[i][j] - m2.array[i][j];
		}
	return m;
}

Matrix operator*(Matrix m1, Matrix m2)
{
	Matrix m;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
		{
			int num = 0;
			for (int k = 0; k < 3; k++)
				num = num + m1.array[i][k] * m2.array[k][j];
			m.array[i][j] = num;
		}
	return m;
}

ostream& operator<<(ostream& out, const Matrix& matrix)
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if (j != 2)
				out << matrix.array[i][j] << " ";
			else
				out << matrix.array[i][j] << endl;
		}
	}
	return out;
}

int main()
{
	// 输入/输出重定向
	// 类比文件读写
	// freopen("data.in", "r", stdin);
	// freopen("data.out", "w", stdout);
	int array1[3][3], array2[3][3];
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			cin >> array1[i][j];
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			cin >> array2[i][j];
	Matrix matrix1(array1), matrix2(array2);
	Matrix m = matrix1 + matrix2;
	cout << m;
	Matrix m1 = matrix1 - matrix2;
	cout << m1;
	Matrix m2 = matrix1 * matrix2;
	cout << m2;
	return 0;
}
