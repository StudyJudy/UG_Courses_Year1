#include<iostream>
#include<stack>
using namespace std;

int main() {
	char str[1000];
	cin >> str;
	int i = 0;
	stack<int>stk;
	while (str[i] != '@') {
		if (str[i] <= '9' && str[i] >= '0') {
			int num = 0;
			while (str[i] != '.') {
				num *= 10;
				num += (str[i] - '0');
				i++;
			}
			stk.push(num);
		}
		else if(str[i]=='+'|| str[i] == '-' || str[i] == '*' || str[i] == '/'){
			int num1 = stk.top();
			stk.pop();
			int num2 = stk.top();
			stk.pop();
			int num;
			switch (str[i])
			{
			case '+':
				num = num1 + num2;
				break;
			case '-':
				num = num2 - num1;
				break;
			case '*':
				num = num1 * num2;
				break;
			case '/':
				num = num2 / num1;
				break;
			default:
				break;
			}
			stk.push(num);
		}
		else {
			cout << "wrong";
			return 0;
		}
		i++;
	}
	cout << stk.top();
	return 0;
}