#include<iostream>
#include<stack>
using namespace std;
int q;
int main() {
	int n;
	int tmp;
	cin >> q;
	while (q > 0) {
		cin >> n;
		int *A = new int[n + 1];
		int *B = new int[n + 1];
		stack<int>stk;
		for (int i = 0; i < n; i++) {
			cin >> A[i];
		}
		for (int i = 0; i < n; i++) {
			cin >> B[i];
		}
		int pA = 0, pB = 0;
		while (pA < n) {
			stk.push(A[pA]);
			while (pB < n && !stk.empty()&&stk.top() == B[pB]) {
					pB++;
					stk.pop();
			}
			pA++;
		}
		if (!stk.empty()) {
			cout << "No" << endl;
		}
		else {
			cout << "Yes" << endl;
		}
		q--;
	}
	return 0;
}
