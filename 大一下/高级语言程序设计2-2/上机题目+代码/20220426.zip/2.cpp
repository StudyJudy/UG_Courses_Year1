#include <iostream>
using namespace std;

// const T (&a)[N]，先看小括号，这里的 a 是一个引用，表示元素类型为 T，长度为 N 的数组，并且数组中的元素不允许修改。
// const T &a[N]，[]的优先级更高，a 是一个数组，数组里存放 T 类型元素的引用，但是 C++ 不允许定义引用数组！！！
template <typename T, int N>
void print(const T (&a)[N])
{
    cout << "(";
    for (int i = 0; i < N; i++)
    {
        cout << a[i];
        if (i != N - 1)
        {
            cout << ", ";
        }
    }
    cout << ")";
}

int main()
{
    int a1[5] {1, 2, 6, 3, 2};
    print(a1);
    cout << endl;

    float a2[5] {3.0f, 4.2f, 1.6f, 2.2f, 6.4f};
    print(a2);
    cout << endl;
    
    double a3[5] {3.0, 4.2, 1.6, 2.2, 6.4};
    print(a3);
    cout << endl;
}