#include <iostream>
using namespace std;

template <typename T>
class MyVector
{
private:
    T *array;     // 指向数组的指针
    int capacity; // 数组已分配空间的大小
    int size;     // 数组中有效元素的个数
    void doubleCapacity();

public:
    MyVector();                       // 创建一个空的数组
    MyVector(int size);               // 创建一个数组，元素个数为 size，默认为零值
    ~MyVector();                      // 析构函数
    int getSize();                    // 返回向量中元素的个数
    int getCapacity();                // 返回当前向量所能容纳的最大元素值
    void push_back(const T & x);      // 尾部添加一个元素 x
    void insert(int pos, const T& x); // 在数组索引 pos 处插入一个元素x
    void pop_back();                  // 删除数组中最后一个元素
    void erase(int pos);              // 删除数组索引 pos 处的元素
    T& at(int pos);                   // 返回 pos 位置元素的引用
};

template <typename T>
MyVector<T>::MyVector()
{
    this->size = 0;
    this->capacity = 0;
    this->array = nullptr; // lazy loading
}

template <typename T>
MyVector<T>::MyVector(int size)
{
    this->size = size;
    this->capacity = size;
    this->array = new T[size];
}

template <typename T>
MyVector<T>::~MyVector()
{
    if (array != nullptr)
    {
        delete array;
    }
}

template <typename T>
int MyVector<T>::getSize()
{
    return size;
}

template <typename T>
int MyVector<T>::getCapacity()
{
    return capacity;
}

template <typename T>
void MyVector<T>::push_back(const T& x)
{
    // 1. 尚未分配空间，先分配空间
    if (array == nullptr)
    {
        capacity = 1;
        array = new T[capacity];
    }
    // 2. 空间不足，扩容
    if (size >= capacity)
    {
        doubleCapacity();
    }
    // 3. 放置元素 x
    array[size++] = x;
}

template <typename T>
void MyVector<T>::insert(int pos, const T& x)
{
    // 0. 检查 pos 合法性
    if (pos < 0 || pos > size)
    {
        return;
    }
    // 1. 尚未分配空间，先分配空间
    if (array == nullptr)
    {
        capacity = 1;
        array = new T[capacity];
    }
    // 2. 空间不足，扩容
    if (size >= capacity)
    {
        doubleCapacity();
    }
    // 3. 将 (pos, size) 范围内的元素后移一位
    for (int i = size; i > pos; i--)
    {
        array[i] = array[i - 1];
    }
    // 4. 放置元素 x
    array[pos] = x;
    size++;
}

template <typename T>
void MyVector<T>::doubleCapacity()
{
    // 扩容为原来的两倍
    int newCapacity = capacity * 2;
    // 申请更大的空间并复制原来的元素
    T *newArray = new T[newCapacity];
    for (int i = 0; i < capacity; i++)
    {
        newArray[i] = array[i];
    }
    // 注意释放原来的空间
    T *temp = array;
    array = newArray;
    delete temp;
    capacity = newCapacity;
}

template <typename T>
void MyVector<T>::pop_back()
{
    // 长度减一，不必真实删除
    size--;
}

template <typename T>
void MyVector<T>::erase(int pos)
{
    // 0. 检查 pos 合法性
    if (pos < 0 || pos >= size)
    {
        return;
    }
    // 1. 将 (pos, size) 范围内的元素前移一位
    for (int i = pos; i < size - 1; i++)
    {
        array[i] = array[i + 1];
    }
    // 2. 长度减一
    size--;
}

template <typename T>
T& MyVector<T>::at(int pos)
{
    return array[pos];
}

int main()
{
    MyVector<int> myVector;
    myVector.insert(0, 1);
    myVector.push_back(1);
    myVector.push_back(2);
    myVector.push_back(3);
    myVector.insert(1, 5);
    cout << myVector.getCapacity() << endl;
    cout << myVector.getSize() << endl;
    for (int i = 0; i < myVector.getSize(); i++)
    {
        cout << myVector.at(i) << " ";
    }
    cout << endl;
    return 0;
}