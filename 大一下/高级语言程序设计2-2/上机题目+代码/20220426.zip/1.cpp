#include <iostream>
using namespace std;

template<class T>
T Min(T a[], int n)
{
    T min = a[0];
    for (int i = 1; i < n; i++)
    {
        if (a[i] < min)
        {
            min =a[i];
        }
        
    }
    return min;
}

template<class T>
T Max(T a[], int n)
{
    T max = a[0];
    for (int i = 1; i < n; i++)
    {
        if (a[i] > max)
        {
            max = a[i];
        }
        
    }
    return max;
}

template<class T>
T Avg(T a[], int n)
{
    T sum = 0;
    for (int i = 0; i < n; i++)
    {
        sum += a[i];
    }
    return sum / n;
}


int main()
{
    // C++ 的模板实现是代入每一个实际类型，针对不同的类型生成不同的代码
    // 如这里的 Min 编译后实际会生成如下三个函数：
    //   int Min<int>(int*, int)
    //   float Min<float>(float*, int)
    //   double Min<double>(double*, int)
    int *a1 = new int[5] {1, 2, 6, 3, 2};
    cout << Min(a1, 5) << endl;
    cout << Max(a1, 5) << endl;
    cout << Avg(a1, 5) << endl;

    float a2[5] {3.0f, 4.2f, 1.6f, 2.2f, 6.4f};
    cout << Min(a2, 5) << endl;
    cout << Max(a2, 5) << endl;
    cout << Avg(a2, 5) << endl;


    double *a3 = new double[5] {3.0, 4.2, 1.6, 2.2, 6.4};
    cout << Min(a3, 5) << endl;
    cout << Max(a3, 5) << endl;
    cout << Avg(a3, 5) << endl;
}