#include <iostream>
using namespace std;

// 为了实现友元函数的声明与实现分离，增加前置定义
template <typename T, int n>
class Array;
template <typename T, int n>
istream &operator>>(istream &in, Array<T, n> &array);
template <typename T, int n>
ostream &operator<<(ostream &out, const Array<T, n> &array);

template <typename T, int n>
class Array
{
private:
    T *array;
    int size;

public:
    Array();
    ~Array();
    T &operator[](int i); // 返回下标为 i 的元素的引用，不考虑异常情况
    int search(T x);      // 查找第一个值为 x 的元素的下标，不存在返回 -1
    // 注意这里多出的 <>，前置声明与后面的定义都不需要
    friend istream &operator>><>(istream &in, Array<T, n> &array);
    friend ostream &operator<<<>(ostream &out, const Array<T, n> &array); // 输出形式为 (1, 2, 3)
};

template <typename T, int n>
Array<T, n>::Array()
{
    size = n;
    array = new T[size];
}

template <typename T, int n>
Array<T, n>::~Array()
{
    delete array;
}

// 返回引用才可以让 arr[i] = x 实现修改对应的元素
template <typename T, int n>
T &Array<T, n>::operator[](int i)
{
    return array[i];
}

template <typename T, int n>
int Array<T, n>::search(T x)
{
    for (int i = 0; i < size; i++)
    {
        if (array[i] == x)
        {
            return i;
        }
    }
    return -1;
}

template <typename T, int n>
istream &operator>>(istream &in, Array<T, n> &array)
{
    for (int i = 0; i < array.size; i++)
    {
        in >> array[i];
    }
}

template <typename T, int n>
ostream &operator<<(ostream &out, const Array<T, n> &array)
{
    out << "(";
    for (int i = 0; i < array.size; i++)
    {
        out << array.array[i];
        if (i != array.size - 1)
        {
            out << ", ";
        }
    }
    out << ")";
}

int main()
{
    Array<int, 5> array;
    cin >> array;
    cout << array << endl;
    array[4] = 5555;
    cout << array << endl;
    cout << array.search(3) << endl;
    cout << array.search(5) << endl;
    return 0;
}