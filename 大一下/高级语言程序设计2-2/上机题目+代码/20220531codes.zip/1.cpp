#include<iostream>
#include<fstream>
#include<map>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;

const int match_num = 6;
const int team_num = 4;

class Team
{
public:
	char name[20];
	int points;
	Team() { points = 0; }
	bool operator<(Team comp) { return this->points > comp.points; }
};

void OutPut_File(Team teams[])
{
	ofstream fout("Standing.bin", ios::out | ios::binary);
	for (int i = 0; i < team_num; i++)
		fout << teams[i].name << " " << teams[i].points << endl;
	fout.close();
}

int main()
{
	ifstream fin("MatchResult.txt", ios::in);
	map<string, int> teams_map;
	for (int i = 0; i < match_num; i++)
	{
		string name1, name2;
		int score1, score2;
		char tmp_c;
		fin >> name1 >> score1 >> tmp_c >> score2 >> name2;
		if (score1 > score2)
		{
			score1 = 3;
			score2 = 0;
		}
		else if (score1 == score2)
			score1 = score2 = 1;
		else
		{
			score1 = 0;
			score2 = 3;
		}
		if (teams_map.find(name1) == teams_map.end())
			teams_map[name1] = 0;
		if (teams_map.find(name2) == teams_map.end())
			teams_map[name2] = 0;
		teams_map[name1] += score1;
		teams_map[name2] += score2;
	}
	fin.close();
	Team *teams = new Team[team_num];
	int i = 0;
	for (map<string, int>::iterator iter = teams_map.begin(); iter != teams_map.end(); iter++)
	{
		strcpy(teams[i].name, iter->first.c_str());
		teams[i++].points = iter->second;
	}
	sort(teams, teams + team_num);
	for (int i = 0; i < team_num; i++)
		cout << teams[i].name << " " << teams[i].points << endl;
	OutPut_File(teams);
	return 0;
}