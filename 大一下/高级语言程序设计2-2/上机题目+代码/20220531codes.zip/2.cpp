#include<iostream>
#include<fstream>
#include<map>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;

const int stu_num = 8;
const int dept_num = 5;

class Student
{
public:
	char *name;
	int score;
	char *dept;
	char *choice1;
	char *choice2;
	char *choice3;

	Student()
	{
		name = new char[30];
		dept = new char[30];
		dept[0] = '\0';
		choice1 = new char[30];
		choice2 = new char[30];
		choice3 = new char[30];
	}

	bool operator<(Student comp) { return this->score > comp.score; }
};

class Department
{
public:
	char *deptName;
	int count;
	int lowest_score;
	int curr_count;

	Department()
	{
		deptName = new char[30];
		curr_count = 0;
	}

	bool operator<(Department comp) { return this->lowest_score > comp.lowest_score; }
};

void Get_Student_Info(Student stu[])
{
	ifstream fin("Student.txt", ios::in);
	for (int i = 0; i < stu_num; i++)
		fin >> stu[i].name >> stu[i].score >> stu[i].choice1 >> stu[i].choice2 >> stu[i].choice3;
	sort(stu, stu + stu_num);
	fin.close();
}

void Get_Dept_Info(Department dept[])
{
	ifstream fin("Department.txt", ios::in);
	for (int i = 0; i < dept_num; i++)
		fin >> dept[i].deptName >> dept[i].count >> dept[i].lowest_score;
	sort(dept, dept + dept_num);
	fin.close();
}

int search_dept(Department dept[], char *deptName)
{
	for (int i = 0; i < dept_num; i++)
		if (strcmp(dept[i].deptName, deptName) == 0)
			return i;
	return -1;
}

void ensure_dept(Student &stu, Department &dept)
{
	strcpy(stu.dept, dept.deptName);
	dept.curr_count++;
}

void Student_Dept(Student stu[], Department dept[])
{
	for (int i = 0; i < stu_num; i++)
	{
		int choice_index[3];
		choice_index[0] = search_dept(dept, stu[i].choice1);
		choice_index[1] = search_dept(dept, stu[i].choice2);
		choice_index[2] = search_dept(dept, stu[i].choice3);
		for (int j = 0; j < 3; j++)
		{
			if (dept[choice_index[j]].curr_count < dept[choice_index[j]].count)
			{
				ensure_dept(stu[i], dept[choice_index[j]]);
				break;
			}
		}
	}
	for (int i = 0; i < stu_num; i++)
	{
		if (stu[i].dept[0] != '\0')
			continue;
		for (int j = 0; j < dept_num; j++)
		{
			if (dept[j].curr_count < dept[j].count)
			{
				ensure_dept(stu[i], dept[j]);
				break;
			}
		}
	}
	ofstream fout("StudentDept.bin", ios::out | ios::binary);
	for (int i = 0; i < stu_num; i++)
		fout << stu[i].name << "\t" << stu[i].score << "\t" << stu[i].dept << endl;
	for (int i = 0; i < stu_num; i++)
		cout << stu[i].name << "\t" << stu[i].score << "\t" << stu[i].dept << endl;
	fout.close();
}

int main()
{
	Student stu[stu_num];
	Department dept[dept_num];
	Get_Student_Info(stu);
	Get_Dept_Info(dept);
	Student_Dept(stu, dept);
	return 0;
}
