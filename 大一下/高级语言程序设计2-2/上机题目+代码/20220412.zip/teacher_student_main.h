#pragma once
#include"teacher_student.h"
void teacher_student() {
	teacherStudentBase* p[50];
	Student* pstud;
	Teacher* ptech;
	char ch;
	int count = 0;
	do {
		cout << "�����ʦ(t)��ѧ��(s):";
		cin >> ch;
		if (ch == 's') {
			pstud = new Student;
			pstud->getName();
			pstud->getNum();
			p[count++] = pstud;
		}
		else if (ch == 't') {
			ptech = new Teacher;
			ptech->getName();
			ptech->getNum();
			p[count++] = ptech;
		}
		else {
			cout << "�������" << endl;
		}
		cout << "����������(y/n)?";
		cin >> ch;
	} while (ch == 'y');
	for (int i = 0; i < count; i++) {
		if (p[i]->isGood()) {
			p[i]->printName();
		}
	}
	return;
}
