#include "edit_string.h"
void m_string() {
	String s1;
	edit_string s2;
	char* cp;
	s1.set_contents("Object_Oriented Programming");
	cp = s1.get_contents();
	s2.set_contents(cp);
	s2.print();

	s2.move_cursor(15);
	s1.set_contents(" Windows");
	s2.add_at_cursor(&s1);
	//s1.set_contents(" Windows");
	//s2.add_at_cursor(&s1);
	s2.print();

	s2.move_cursor(6);
	s2.dele_at_cursor(9);
	//s2.dele_at_cursor(50);
	s2.print();

	s1.set_contents(" TTT");
	s2.repl_at_cursor(&s1);
	s2.print();
	s1.set_contents(" TTTTTTTTTTTTTTTTTTTTTTTTTTTTT");
	s2.repl_at_cursor(&s1);
	s2.print();

}