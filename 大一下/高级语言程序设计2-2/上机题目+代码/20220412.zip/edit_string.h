#pragma once
#include<iostream>
using namespace std;
#ifndef MAX_LEN 
#define MAX_LEN 10000
#endif
class String {
	int length;
	char* contents;
public:
	int get_length() { return length; }
	char* get_contents() { return contents; }
	~String() { delete contents; }
	int set_contents(const char* in_contents) {
		contents = new char[MAX_LEN];
		int len = 0;
		while (in_contents[len] != '\0')
			contents[len++] = in_contents[len];
		contents[len] = '\0';
		length = len;
		return 0;
	}
	void print() { cout << contents << endl; }
	void set_length(int new_length) {
		length = new_length;
	}
};
class edit_string :public String
{
	int cursor;
public:
	int get_cursor_pos() { return cursor; }
	void move_cursor(int how_much) { cursor = how_much; }
	int add_at_cursor(String* new_text);
	int repl_at_cursor(String* new_text);
	void dele_at_cursor(int how_much);
};

int edit_string::add_at_cursor(String* how_much) {
	char* contents = get_contents();

	char* contents_behind_cursor = new char[MAX_LEN];
	int contents_behind_cursor_len = get_length() - cursor;
	for (int i = 0; i + cursor <= get_length(); i++)
		contents_behind_cursor[i] = contents[i + cursor];

	for (int i = 0; i < how_much->get_length(); i++)
		contents[cursor + i] = how_much->get_contents()[i];

	for (int j = 0; j <= contents_behind_cursor_len; j++)
		contents[j + cursor + how_much->get_length()] = contents_behind_cursor[j];
	//get_length() = get_length() + how_much->get_length();
	set_length(get_length() + how_much->get_length());
	return 0;
}

int edit_string::repl_at_cursor(String* how_much) {
	char* contents = get_contents();
	char* how_much_contents = how_much->get_contents();
	for (int i = 0; i < how_much->get_length(); i++)
		contents[i + cursor] = how_much_contents[i];
	if (cursor + how_much->get_length() > get_length()) {
		set_length(cursor + how_much->get_length());
		contents[cursor + how_much->get_length() + 1] = '\0';
	}
	return 0;
}
void edit_string::dele_at_cursor(int how_much) {
	char* contents = get_contents();
	for (int i = 0; i <= get_length() - (how_much + cursor); i++) {
		contents[cursor + i] = contents[cursor + i + how_much];
	}
	if (cursor + how_much > get_length()) {
		contents[cursor + 1] = '\0';
		set_length(cursor);
	}
	else
		set_length(get_length() - how_much);
	return;
}

