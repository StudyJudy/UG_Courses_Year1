#pragma once
#include<iostream>
#include<string>
#include<cstdio>
#include<cstring>
#include<sstream>
#include<cstdlib>
using namespace std;

class StudentInformation {
	string name;
	int age;
	string id;
	int score[4];
	float mean_score;
public:
	//StudentInformation() { score = new int[4]; }
	void input() {
		string input, buffer;
		cin >> input;
		istringstream s(input);

		getline(s, buffer, ',');
		name = buffer;
		
		getline(s, buffer, ',');
		stringstream buffer_stream;
		buffer_stream << buffer;
		buffer_stream >> age;
		buffer_stream.clear();

		getline(s, buffer, ',');
		id = buffer;
		getline(s, buffer, ',');
		buffer_stream << buffer;
		buffer_stream >> score[0];
		buffer_stream.clear();
		getline(s, buffer, ',');
		buffer_stream << buffer;
		buffer_stream >> score[1];
		buffer_stream.clear();
		getline(s, buffer, ',');
		buffer_stream << buffer;
		buffer_stream >> score[2];
		buffer_stream.clear();
		getline(s, buffer, ',');
		buffer_stream << buffer;
		buffer_stream >> score[3];
		buffer_stream.clear();
	}

	void calculate() {
		float sum_score = 0;
		for (int i = 0; i < 4; i++)
			sum_score += score[i];
		mean_score = sum_score / 4;
	}

	void output() {
		cout << name << "," << age << "," << id << "," << mean_score << endl;
	}
};

void student_information() {
	StudentInformation student;
	student.input();
	student.calculate();
	student.output();
}