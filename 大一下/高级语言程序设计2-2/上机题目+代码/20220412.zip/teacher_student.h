#pragma once
#include<iostream>
using namespace std;
#ifndef MAX_LEN 
#define MAX_LEN 10000
#endif
class teacherStudentBase {
	char* name;
public:
	teacherStudentBase() { name = new char[MAX_LEN]; }
	void getName() {
		cout << "������";
		cin >> name;
	}
	void printName() { cout << "������" << name << endl; }
	virtual bool isGood() = 0;
	~teacherStudentBase() { delete name; }
};

class Student :public teacherStudentBase {
	int num;
public:
	void getNum() { 
		cout << "���Գɼ���";
		cin >> num;
	}
	bool isGood() { return num > 90; }
};

class Teacher :public teacherStudentBase {
	int num;
public:
	void getNum() {
		cout << "ÿ�귢����������";
		cin >> num;
	}
	bool isGood() { return num > 3; }
};
