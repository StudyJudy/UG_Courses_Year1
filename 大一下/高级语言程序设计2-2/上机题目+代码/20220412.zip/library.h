#pragma once
#include<iostream>
using namespace std;
#ifndef MAX_LEN 
#define MAX_LEN 10000
#endif

class libraryBase {
	char* title;
	int sold;
public:
	libraryBase() { title = new char[MAX_LEN]; }
	~libraryBase() { delete title; }
	void getTitle() {
		cout << "������";
		cin >> title;
	}
	void getSold() {
		cout << "ÿ������������";
		cin >> sold;
	}
	virtual bool isGood() = 0;
	int getSoldNum() { return sold; }
	void printTitle() { cout << title; }
};

class Book :public libraryBase {
public:
	bool isGood() { return getSoldNum() > 500; }
};

class Journal : public libraryBase {
public:
	bool isGood() { return getSoldNum() > 2500; }
};