#include "edit_string_main.h"
#include "teacher_student_main.h"
#include "library_main.h"
#include "student_information.h"
#include "mystring.h"
void main() {
	//m_string();
	//teacher_student();
	//library();
	//student_information();
	mystring();
}