#include <iostream>
#include <cstring>
using namespace std;
class MyString
{
private:
    char *p;

public:
    MyString(const char *s)
    {
        if (s != NULL)
        {
            // 这里需要注意，不能直接 p = s，不然 s 发生变化，对象中的字符也会变化，这是不符合逻辑的。
            // 后面的拷贝构造函数，Copy 以及重载赋值运算符都是这个道理。
            // 考察知识点：深拷贝与浅拷贝
            p = new char[strlen(s) + 1];
            strcpy(p, s);
        }
        else
        {
            p = NULL;
        }
    }

    ~MyString()
    {
        if (p != NULL)
        {
            delete[] p;
        }
    }

    // 拷贝构造函数
    MyString(const MyString &s)
    {
        if (s.p != NULL)
        {
            p = new char[strlen(s.p) + 1];
            strcpy(p, s.p);
        }
        else
        {
            p = NULL;
        }
    }

    // 从字符指针 s 拷贝字符串
    void Copy(const char *s)
    {
        if (p != NULL)
        {
            delete[] p;
        }
        if (s != NULL)
        {
            p = new char[strlen(s) + 1];
            strcpy(p, s);
        }
        else
        {
            p = NULL;
        }
    }

    friend ostream &operator<<(ostream &os, MyString &s)
    {
        os << s.p;
        return os;
    }

    // 重载赋值运算符
    MyString &operator=(const char *s)
    {
        if (p != NULL)
        {
            delete[] p;
        }
        if (s != NULL)
        {
            p = new char[strlen(s) + 1];
            strcpy(p, s);
        }
        else
        {
            p = NULL;
        }
        return *this;
    }

    // 重载赋值运算符
    MyString &operator=(const MyString &s)
    {
        if (p != NULL)
        {
            delete[] p;
        }
        if (s.p != NULL)
        {
            p = new char[strlen(s.p) + 1];
            strcpy(p, s.p);
        }
        else
        {
            p = NULL;
        }
        return *this;
    }
};

int main()
{
    char w1[200], w2[100];
    while (cin >> w1 >> w2)
    {
        MyString s1(w1), s2 = s1;
        MyString s3(NULL);
        s3.Copy(w1);
        cout << s1 << "," << s2 << "," << s3 << endl;

        s2 = w2;
        s3 = s2;
        s1 = s3;
        cout << s1 << "," << s2 << "," << s3 << endl;
    }
}