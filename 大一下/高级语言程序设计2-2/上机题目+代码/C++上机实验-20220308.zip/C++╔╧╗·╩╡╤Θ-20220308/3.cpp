#include <iostream>
using namespace std;

class Date
{
public:
    Date() {}
    Date(int year, int month, int day);
    void showDate();
    void setDate(int year, int month, int day);
    ~Date() {}

private:
    int year;
    int month;
    int day;
};

class Person
{
public:
    Person(long num, char sex, long id, int year, int month, int day) : date(year, month, day)
    {
        this->num = num;
        this->sex = sex;
        this->id = id;
    }
    Person(int year, int month = 1, int day = 1) : date(year, month, day) {}
    Person() {}
    Person(const Person &p);
    void setPerson();
    void showPerson();
    ~Person() {}

private:
    long num;
    char sex;
    Date date;
    long id;
};

Date::Date(int year, int month, int day)
{
    this->year = year;
    this->month = month;
    this->day = day;
}
void Date::showDate()
{
    cout << "year-month-day:  " << year << "-" << month << "-" << day << endl;
}
void Date::setDate(int year, int month, int day)
{
    this->year = year;
    this->month = month;
    this->day = day;
}

Person::Person(const Person &p)
{
    this->num = p.num;
    this->id = p.id;
    this->sex = p.sex;
}

void Person::showPerson()
{
    cout << "num: " << num << endl;
    cout << "sex: " << sex << endl;
    cout << "date: ";
    date.showDate();
    cout << "id: " << id << endl;
}

void Person::setPerson()
{
    int year;
    int month;
    int day;
    cout << "请输入编号: ";
    cin >> this->num;
    cout << "请输入性别（M/F）: ";
    cin >> this->sex;
    cout << "请输入身份证号: ";
    cin >> this->id;
    cout << "请输入出生年月日（yyyy MM dd）:" << endl;
    cin >> year >> month >> day;
    this->date.setDate(year, month, day);
}

int main()
{
    Person p;
    p.setPerson();
    p.showPerson();

    return 0;
}