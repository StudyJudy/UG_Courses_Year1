#include <iostream>
using namespace std;
class Yuebao
{
public:
    // 设定“余额宝”的利率
    static void setProfitRate(double rate)
    {
        profitRate = rate;
    }

    // 构造函数
    Yuebao(double money)
    {
        this->money = money;
    }

    // 获得前一天的利息
    void addProfit()
    {
        money += money * profitRate;
    }

    // 存钱
    void deposit(double amount)
    {
        money += amount;
    }

    // 取钱
    void withdraw(double amount)
    {
        money -= amount;
    }

    // 获取当前余额
    double getBalance()
    {
        return money;
    }

private:
    static double profitRate;
    double money = 0;
};

double Yuebao::profitRate = 0;

int main()
{
    int n;
    while (cin >> n)
    {
        double profitRate;
        cin >> profitRate;
        Yuebao::setProfitRate(profitRate); //设定余额宝的利率
        Yuebao y(0);                       //新建余额宝账户，余额初始化为0
        int operation;                     //接受输入判断是存还是取
        double amount;                     //接受输入存取金额
        for (int i = 0; i < n; i++)
        {
            y.addProfit(); //加入前一天余额产生的利息
            cin >> operation >> amount;
            if (operation == 0)
                y.deposit(amount); //存入金额
            else
                y.withdraw(amount); //取出金额
        }
        cout << y.getBalance() << endl;
        //输出最终账户余额
    }
    return 0;
}