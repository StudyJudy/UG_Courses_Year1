#include <iostream>
using namespace std;

class Complex
{
public:
    Complex(double r, double i) : real(r), image(i) {}
    Complex(double r) : real(r), image(0) {}
    void show();
    void add(const Complex &c2);

private:
    double real;
    double image;
};

void Complex::add(const Complex &c2)
{
    this->real += c2.real;
    this->image += c2.image;
}

void Complex::show()
{
    if (this->image == 0)
    {
        cout << this->real << endl;
    }
    else
    {
        cout << this->real;
        if (this->image < 0)
        {
            cout << this->image << "i" << endl;
        }
        else
        {
            cout << "+" << this->image << "i" << endl;
        }
    }
}

int main()
{
    Complex c1(1.4, 2.3);
    Complex c4(4.5, -4.5);
    c1.show();
    c1.add(c4);
    c1.show();

    return 0;
}