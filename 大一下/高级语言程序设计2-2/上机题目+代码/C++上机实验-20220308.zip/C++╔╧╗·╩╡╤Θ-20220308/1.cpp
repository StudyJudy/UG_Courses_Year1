#include <iostream>
using namespace std;

class Dog
{
public:
    Dog(int age = 0, double weight = 20)
    {
        this->age = age;
        this->weight = weight;
    }
    ~Dog() {}
    
    int getAge()
    {
        return this->age;
    }
    void setAge(int age)
    {
        this->age = age;
    }
    void setWeight(double weight)
    {
        this->weight = weight;
    }
    double getWeight()
    {
        return this->weight;
    }

private:
    int age;
    double weight;
};

int main()
{
    Dog Jack(2, 15);
    cout << "Jack is a Dog who is ";
    cout << Jack.getAge() << " years old and " << Jack.getWeight() << " pounds weight" << endl;
    Jack.setAge(13);
    Jack.setWeight(22);
    cout << "Now Jack is ";
    cout << Jack.getAge() << " years old and " << Jack.getWeight() << " pounds weight" << endl;

    return 0;
}