#include <iostream>
using namespace std;

class Complex
{
public:
    Complex(double r, double i) : real(r), image(i) {}
    Complex(double r) : real(r), image(0) {}
    friend Complex operator+(const Complex &c1, const Complex &c2);
    friend Complex operator-(const Complex &c1, const Complex &c2);
    friend Complex operator*(const Complex &c1, const Complex &c2);
    friend Complex operator/(const Complex &c1, const Complex &c2);
    friend bool operator==(const Complex &c1, const Complex &c2);
    friend ostream &operator<<(ostream &out, const Complex &c);
    friend istream &operator>>(istream &in, Complex &c);
    void show();

private:
    double real;
    double image;
};

Complex operator+(const Complex &c1, const Complex &c2)
{
    Complex c(0, 0);
    c.real = c1.real + c2.real;
    c.image = c1.image + c2.image;
    return c;
}

Complex operator-(const Complex &c1, const Complex &c2)
{
    Complex c(0, 0);
    c.real = c1.real - c2.real;
    c.image = c1.image - c2.image;
    return c;
}

Complex operator*(const Complex &c1, const Complex &c2)
{
    Complex c(0, 0);
    c.real = c1.real * c2.real - c1.image * c2.image;
    c.image = c1.image * c2.real + c1.real * c2.image;
    return c;
}

Complex operator/(const Complex &c1, const Complex &c2)
{
    Complex c(0, 0);
    double t = c2.real * c2.real + c2.image * c2.image;
    c.real = (c1.real * c2.real + c1.image * c2.image) / t;
    c.image = (c1.image * c2.real - c1.real * c2.image) / t;
    return c;
}

bool operator==(const Complex &c1, const Complex &c2)
{
    return c1.real == c2.real && c1.image == c2.image;
}

ostream &operator<<(ostream &out, const Complex &c)
{
    if (c.image == 0)
    {
        out << c.real;
    }
    else
    {
        out << c.real;
        if (c.image < 0)
        {
            out << c.image << "i";
        }
        else
        {
            out << "+" << c.image << "i";
        }
    }
}

istream &operator>>(istream &in, Complex &c)
{
    in >> c.real >> c.image;
}

int main()
{
    Complex c1(0);
    Complex c4(0);
    cin >> c1 >> c4;
    cout << c1 << endl;
    Complex c = c1 + c4;
    cout << c << endl;

    cout << (c1 + c4) << endl;
    cout << (c1 - c4) << endl;
    cout << (c1 * c4) << endl;
    cout << (c1 / c4) << endl;

    cout << (c1 == c4) << endl;
    return 0;
}